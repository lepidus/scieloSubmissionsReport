-- MySQL dump 10.13  Distrib 8.0.23, for Linux (x86_64)
--
-- Host: localhost    Database: ops_stable_3_2_1
-- ------------------------------------------------------
-- Server version	8.0.23-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_keys`
--

DROP TABLE IF EXISTS `access_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_keys` (
  `access_key_id` bigint NOT NULL AUTO_INCREMENT,
  `context` varchar(40) NOT NULL,
  `key_hash` varchar(40) NOT NULL,
  `user_id` bigint NOT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `expiry_date` datetime NOT NULL,
  PRIMARY KEY (`access_key_id`),
  KEY `access_keys_hash` (`key_hash`,`user_id`,`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_keys`
--

LOCK TABLES `access_keys` WRITE;
/*!40000 ALTER TABLE `access_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_settings`
--

DROP TABLE IF EXISTS `announcement_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_settings` (
  `announcement_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `announcement_settings_pkey` (`announcement_id`,`locale`,`setting_name`),
  KEY `announcement_settings_announcement_id` (`announcement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_settings`
--

LOCK TABLES `announcement_settings` WRITE;
/*!40000 ALTER TABLE `announcement_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_type_settings`
--

DROP TABLE IF EXISTS `announcement_type_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_type_settings` (
  `type_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `announcement_type_settings_pkey` (`type_id`,`locale`,`setting_name`),
  KEY `announcement_type_settings_type_id` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_type_settings`
--

LOCK TABLES `announcement_type_settings` WRITE;
/*!40000 ALTER TABLE `announcement_type_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_type_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_types`
--

DROP TABLE IF EXISTS `announcement_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_types` (
  `type_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` smallint DEFAULT NULL,
  `assoc_id` bigint NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `announcement_types_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_types`
--

LOCK TABLES `announcement_types` WRITE;
/*!40000 ALTER TABLE `announcement_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `announcement_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` smallint DEFAULT NULL,
  `assoc_id` bigint NOT NULL,
  `type_id` bigint DEFAULT NULL,
  `date_expire` datetime DEFAULT NULL,
  `date_posted` datetime NOT NULL,
  PRIMARY KEY (`announcement_id`),
  KEY `announcements_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_sources`
--

DROP TABLE IF EXISTS `auth_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_sources` (
  `auth_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `plugin` varchar(32) NOT NULL,
  `auth_default` tinyint NOT NULL DEFAULT '0',
  `settings` text,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_sources`
--

LOCK TABLES `auth_sources` WRITE;
/*!40000 ALTER TABLE `auth_sources` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_settings`
--

DROP TABLE IF EXISTS `author_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_settings` (
  `author_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) DEFAULT NULL,
  UNIQUE KEY `author_settings_pkey` (`author_id`,`locale`,`setting_name`),
  KEY `author_settings_author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_settings`
--

LOCK TABLES `author_settings` WRITE;
/*!40000 ALTER TABLE `author_settings` DISABLE KEYS */;
INSERT INTO `author_settings` VALUES (1,'','country','',NULL),(1,'','orcid','',NULL),(1,'','url','',NULL),(1,'pt_BR','affiliation','',NULL),(1,'pt_BR','biography','',NULL),(1,'pt_BR','familyName','duarte',NULL),(1,'pt_BR','givenName','duarte',NULL),(2,'','country','',NULL),(2,'','orcid','',NULL),(2,'','url','',NULL),(2,'pt_BR','affiliation','',NULL),(2,'pt_BR','biography','',NULL),(2,'pt_BR','familyName','duarte',NULL),(2,'pt_BR','givenName','duarte',NULL);
/*!40000 ALTER TABLE `author_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `author_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(90) NOT NULL,
  `include_in_browse` tinyint NOT NULL DEFAULT '1',
  `publication_id` bigint DEFAULT NULL,
  `submission_id` bigint DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `user_group_id` bigint DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  KEY `authors_publication_id` (`publication_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'nao@lepidus.com.br',1,1,NULL,0,2),(2,'nao@lepidus.com.br',1,2,NULL,0,2);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `parent_id` bigint NOT NULL,
  `seq` bigint DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `image` text,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_path` (`context_id`,`path`),
  KEY `category_context_id` (`context_id`,`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_settings`
--

DROP TABLE IF EXISTS `category_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_settings` (
  `category_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `category_settings_pkey` (`category_id`,`locale`,`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_settings`
--

LOCK TABLES `category_settings` WRITE;
/*!40000 ALTER TABLE `category_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citation_settings`
--

DROP TABLE IF EXISTS `citation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `citation_settings` (
  `citation_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `citation_settings_pkey` (`citation_id`,`locale`,`setting_name`),
  KEY `citation_settings_citation_id` (`citation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citation_settings`
--

LOCK TABLES `citation_settings` WRITE;
/*!40000 ALTER TABLE `citation_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `citation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citations`
--

DROP TABLE IF EXISTS `citations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `citations` (
  `citation_id` bigint NOT NULL AUTO_INCREMENT,
  `publication_id` bigint NOT NULL DEFAULT '0',
  `raw_citation` text,
  `seq` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`citation_id`),
  UNIQUE KEY `citations_publication_seq` (`publication_id`,`seq`),
  KEY `citations_publication` (`publication_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citations`
--

LOCK TABLES `citations` WRITE;
/*!40000 ALTER TABLE `citations` DISABLE KEYS */;
/*!40000 ALTER TABLE `citations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entries`
--

DROP TABLE IF EXISTS `controlled_vocab_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entries` (
  `controlled_vocab_entry_id` bigint NOT NULL AUTO_INCREMENT,
  `controlled_vocab_id` bigint NOT NULL,
  `seq` double DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_entry_id`),
  KEY `controlled_vocab_entries_cv_id` (`controlled_vocab_id`,`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entries`
--

LOCK TABLES `controlled_vocab_entries` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entries` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entries` VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,1),(5,2,2),(6,2,3),(7,2,4),(8,2,5),(9,2,6),(10,2,7),(11,3,1),(12,3,2),(13,3,3),(14,4,1),(15,4,2),(16,4,3),(17,4,4),(18,4,5),(19,4,6),(20,4,7),(21,4,8),(22,4,9),(23,4,10),(24,4,11),(25,4,12),(26,5,1),(27,5,2);
/*!40000 ALTER TABLE `controlled_vocab_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entry_settings`
--

DROP TABLE IF EXISTS `controlled_vocab_entry_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entry_settings` (
  `controlled_vocab_entry_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `c_v_e_s_pkey` (`controlled_vocab_entry_id`,`locale`,`setting_name`),
  KEY `c_v_e_s_entry_id` (`controlled_vocab_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entry_settings`
--

LOCK TABLES `controlled_vocab_entry_settings` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entry_settings` VALUES (1,'','name','personal','string'),(2,'','name','corporate','string'),(3,'','name','conference','string'),(4,'','description','Author','string'),(4,'','name','aut','string'),(5,'','description','Contributor','string'),(5,'','name','ctb','string'),(6,'','description','Editor','string'),(6,'','name','edt','string'),(7,'','description','Illustrator','string'),(7,'','name','ill','string'),(8,'','description','Photographer','string'),(8,'','name','pht','string'),(9,'','description','Sponsor','string'),(9,'','name','spn','string'),(10,'','description','Translator','string'),(10,'','name','trl','string'),(11,'','name','multimedia','string'),(12,'','name','still image','string'),(13,'','name','text','string'),(14,'','name','article','string'),(15,'','name','book','string'),(16,'','name','conference publication','string'),(17,'','name','issue','string'),(18,'','name','journal','string'),(19,'','name','newspaper','string'),(20,'','name','picture','string'),(21,'','name','review','string'),(22,'','name','periodical','string'),(23,'','name','series','string'),(24,'','name','thesis','string'),(25,'','name','web site','string'),(26,'','name','electronic','string'),(27,'','name','print','string');
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocabs`
--

DROP TABLE IF EXISTS `controlled_vocabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocabs` (
  `controlled_vocab_id` bigint NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(64) NOT NULL,
  `assoc_type` bigint NOT NULL DEFAULT '0',
  `assoc_id` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`controlled_vocab_id`),
  UNIQUE KEY `controlled_vocab_symbolic` (`symbolic`,`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocabs`
--

LOCK TABLES `controlled_vocabs` WRITE;
/*!40000 ALTER TABLE `controlled_vocabs` DISABLE KEYS */;
INSERT INTO `controlled_vocabs` VALUES (6,'interest',0,0),(4,'mods34-genre-marcgt',0,0),(2,'mods34-name-role-roleTerms-marcrelator',0,0),(1,'mods34-name-types',0,0),(5,'mods34-physicalDescription-form-marcform',0,0),(3,'mods34-typeOfResource',0,0),(11,'submissionAgency',1048588,1),(16,'submissionAgency',1048588,2),(9,'submissionDiscipline',1048588,1),(14,'submissionDiscipline',1048588,2),(7,'submissionKeyword',1048588,1),(12,'submissionKeyword',1048588,2),(10,'submissionLanguage',1048588,1),(15,'submissionLanguage',1048588,2),(8,'submissionSubject',1048588,1),(13,'submissionSubject',1048588,2);
/*!40000 ALTER TABLE `controlled_vocabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_oai_set_objects`
--

DROP TABLE IF EXISTS `data_object_tombstone_oai_set_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_oai_set_objects` (
  `object_id` bigint NOT NULL AUTO_INCREMENT,
  `tombstone_id` bigint NOT NULL,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  PRIMARY KEY (`object_id`),
  KEY `data_object_tombstone_oai_set_objects_tombstone_id` (`tombstone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_oai_set_objects`
--

LOCK TABLES `data_object_tombstone_oai_set_objects` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_settings`
--

DROP TABLE IF EXISTS `data_object_tombstone_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_settings` (
  `tombstone_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `data_object_tombstone_settings_pkey` (`tombstone_id`,`locale`,`setting_name`),
  KEY `data_object_tombstone_settings_tombstone_id` (`tombstone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_settings`
--

LOCK TABLES `data_object_tombstone_settings` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstones`
--

DROP TABLE IF EXISTS `data_object_tombstones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstones` (
  `tombstone_id` bigint NOT NULL AUTO_INCREMENT,
  `data_object_id` bigint NOT NULL,
  `date_deleted` datetime NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`tombstone_id`),
  KEY `data_object_tombstones_data_object_id` (`data_object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstones`
--

LOCK TABLES `data_object_tombstones` WRITE;
/*!40000 ALTER TABLE `data_object_tombstones` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doi_screening`
--

DROP TABLE IF EXISTS `doi_screening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doi_screening` (
  `doi_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `doi_code` varchar(255) NOT NULL,
  PRIMARY KEY (`doi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=676 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doi_screening`
--

LOCK TABLES `doi_screening` WRITE;
/*!40000 ALTER TABLE `doi_screening` DISABLE KEYS */;
INSERT INTO `doi_screening` VALUES (1,375,'10.1016/j.heliyon.2020.e03542'),(2,375,'10.1016/j.ctim.2020.102321'),(3,375,'10.1016/j.heliyon.2020.e03542'),(4,375,'10.1016/j.ctim.2020.102321'),(5,375,'10.1016/j.ctim.2020.102321'),(6,375,'10.1016/j.heliyon.2020.e03542'),(7,403,'10.1590/0102-311X00ED010616'),(8,403,'10.1590/0102-311X00120416'),(9,403,'10.1186/1476-072X-13-13'),(10,403,'10.1590/0102-311X00ED010616'),(11,403,'10.1590/0102-311X00120416'),(12,403,'10.1186/1476-072X-13-13'),(13,403,'10.1590/0102-311X00ED010616'),(14,403,'10.1590/0102-311X00120416'),(15,403,'10.1186/1476-072X-13-13'),(16,403,'10.1590/0102-311X00ED010616'),(17,403,'10.1590/0102-311X00120416'),(18,403,'10.1186/1476-072X-13-13'),(19,403,'10.1590/0102-311X00ED010616'),(20,403,'10.1590/0102-311X00120416'),(21,403,'10.1186/1476-072X-13-13'),(22,404,'10.1186/1476-072X-13-13'),(23,404,'10.1590/0102-311X00ED010616'),(24,404,'10.1590/0102-311X00120416'),(25,404,'10.1186/1476-072X-13-13'),(26,404,'10.1590/0102-311X00ED010616'),(27,404,'10.1590/0102-311X00120416'),(28,404,'10.1186/s12890-019-0855-1'),(29,404,'10.1016/j.ijpara.2018.11.008'),(30,404,'10.1016/j.vetpar.2018.08.016'),(31,404,'10.1186/s12890-019-0855-1'),(32,404,'10.1016/j.ijpara.2018.11.008'),(33,404,'10.1016/j.vetpar.2018.08.016'),(34,442,'10.1590/0001-3765202020180584'),(35,442,'10.5123/s1679-49742020000200008'),(36,442,'10.1590/0001-3765202020180584'),(37,442,'10.5123/s1679-49742020000200008'),(38,442,'10.1590/0001-3765202020180584'),(39,442,'10.5123/s1679-49742020000200008'),(40,442,'10.1080/20477724.2019.1574111'),(41,442,'10.1590/0001-3765202020180584'),(42,442,'10.5123/s1679-49742020000200008'),(43,442,'10.1080/20477724.2019.1574111'),(44,442,'10.1590/0001-3765202020180584'),(45,442,'10.5123/s1679-49742020000200008'),(46,442,'10.1080/20477724.2019.1574111'),(47,442,'10.1590/0001-3765202020180584'),(48,442,'10.5123/s1679-49742020000200008'),(49,442,'10.1080/20477724.2019.1574111'),(50,442,'10.1590/0001-3765202020180584'),(51,442,'10.5123/s1679-49742020000200008'),(52,442,'10.1080/20477724.2019.1574111'),(53,442,'10.1080/20477724.2019.1574111'),(54,442,'10.5123/s1679-49742020000200008'),(55,442,'10.1590/0001-3765202020180584'),(56,442,'10.1080/20477724.2019.1574111'),(57,442,'10.5123/s1679-49742020000200008'),(58,442,'10.1590/0001-3765202020180584'),(59,442,'10.1080/20477724.2019.1574111'),(60,442,'10.5123/s1679-49742020000200008'),(61,442,'10.1590/0001-3765202020180584'),(62,442,'10.1080/20477724.2019.1574111'),(63,442,'10.5123/s1679-49742020000200008'),(64,442,'10.1590/0001-3765202020180584'),(65,442,'10.1080/20477724.2019.1574111'),(66,442,'10.5123/s1679-49742020000200008'),(67,442,'10.1590/0001-3765202020180584'),(68,442,'10.1080/20477724.2019.1574111'),(69,442,'10.5123/s1679-49742020000200008'),(70,442,'10.1590/0001-3765202020180584'),(71,442,'10.1080/20477724.2019.1574111'),(72,442,'10.5123/s1679-49742020000200008'),(73,442,'10.1590/0001-3765202020180584'),(74,442,'10.1080/20477724.2019.1574111'),(75,442,'10.5123/s1679-49742020000200008'),(76,442,'10.1590/0001-3765202020180584'),(77,442,'10.1080/20477724.2019.1574111'),(78,442,'10.5123/s1679-49742020000200008'),(79,442,'10.1590/0001-3765202020180584'),(80,442,'10.1080/20477724.2019.1574111'),(81,442,'10.5123/s1679-49742020000200008'),(82,442,'10.1590/0001-3765202020180584'),(83,442,'10.1080/20477724.2019.1574111'),(84,442,'10.5123/s1679-49742020000200008'),(85,442,'10.1590/0001-3765202020180584'),(86,442,'10.1080/20477724.2019.1574111'),(87,442,'10.5123/s1679-49742020000200008'),(88,442,'10.1590/0001-3765202020180584'),(89,442,'10.1080/20477724.2019.1574111'),(90,442,'10.5123/s1679-49742020000200008'),(91,442,'10.1590/0001-3765202020180584'),(92,446,'10.1590/1983-1447.2018.2018-0009'),(93,446,'10.1590/1981-22562018021.170137'),(94,446,'10.1590/1983-1447.2018.2018-0009'),(95,446,'10.1590/1981-22562018021.170137'),(96,446,'10.1590/1983-1447.2018.2018-0009'),(97,446,'10.1590/1981-22562018021.170137'),(98,446,'10.5935/1415-2762.20160016'),(99,446,'10.1590/1983-1447.2018.2018-0009'),(100,446,'10.1590/1981-22562018021.170137'),(101,446,'10.5935/1415-2762.20160016'),(102,446,'10.1590/1983-1447.2018.2018-0009'),(103,446,'10.1590/1981-22562018021.170137'),(104,446,'10.5935/1415-2762.20160016'),(105,446,'10.1590/1981-22562018021.170137'),(106,446,'10.1590/1983-1447.2018.2018-0009'),(107,446,'10.5935/1415-2762.20160016'),(108,446,'10.1590/1981-22562018021.170137'),(109,446,'10.1590/1983-1447.2018.2018-0009'),(110,446,'10.5935/1415-2762.20160016'),(111,446,'10.1590/1981-22562018021.170137'),(112,446,'10.1590/1983-1447.2018.2018-0009'),(113,446,'10.5935/1415-2762.20160016'),(114,446,'10.1590/1981-22562018021.170137'),(115,446,'10.1590/1983-1447.2018.2018-0009'),(116,446,'10.5935/1415-2762.20160016'),(117,446,'10.1590/1981-22562018021.170137'),(118,446,'10.1590/1983-1447.2018.2018-0009'),(119,446,'10.5935/1415-2762.20160016'),(120,446,'10.1590/1981-22562018021.170137'),(121,446,'10.1590/1983-1447.2018.2018-0009'),(122,446,'10.5935/1415-2762.20160016'),(123,458,'10.3389/fbioe.2019.00200'),(124,458,'10.1016/j.mimet.2018.07.024'),(125,458,'10.3389/fbioe.2019.00200'),(126,458,'10.1016/j.mimet.2018.07.024'),(127,458,'10.3389/fbioe.2019.00200'),(128,458,'10.1016/j.mimet.2018.07.024'),(129,458,'10.3389/fbioe.2019.00200'),(130,458,'10.1016/j.mimet.2018.07.024'),(131,458,'10.1007/s10142-018-0610-3'),(132,458,'10.3389/fbioe.2019.00200'),(133,458,'10.1016/j.mimet.2018.07.024'),(134,458,'10.1007/s10142-018-0610-3'),(135,465,'10.15446/av.enferm.v38n1.79093'),(136,465,'10.1590/s1980-220x2018030003527'),(137,465,'10.15446/av.enferm.v38n1.79093'),(138,465,'10.1590/s1980-220x2018030003527'),(139,465,'10.1590/1806-93042019000200013'),(140,465,'10.15446/av.enferm.v38n1.79093'),(141,465,'10.1590/s1980-220x2018030003527'),(142,465,'10.1590/1806-93042019000200013'),(143,465,'10.15446/av.enferm.v38n1.79093'),(144,465,'10.1590/s1980-220x2018030003527'),(145,465,'10.1590/1806-93042019000200013'),(146,465,'10.1590/s1980-220x2018030003527'),(147,465,'10.15446/av.enferm.v38n1.79093'),(148,465,'10.1590/s1980-220x2018030003527'),(149,465,'10.15446/av.enferm.v38n1.79093'),(150,465,'10.1590/1806-93042019000200013'),(151,465,'10.1590/s1980-220x2018030003527'),(152,465,'10.15446/av.enferm.v38n1.79093'),(153,465,'10.1590/1806-93042019000200013'),(154,465,'10.1590/s1980-220x2018030003527'),(155,465,'10.15446/av.enferm.v38n1.79093'),(156,465,'10.1590/1806-93042019000200013'),(157,465,'10.1590/s1980-220x2018030003527'),(158,465,'10.15446/av.enferm.v38n1.79093'),(159,465,'10.1590/1806-93042019000200013'),(160,465,'10.1590/1806-93042019000200013'),(161,465,'10.15446/av.enferm.v38n1.79093'),(162,476,'10.1002/da.22915'),(163,476,'10.1249/JSR.0000000000000620'),(164,476,'10.1002/da.22915'),(165,476,'10.1249/JSR.0000000000000620'),(166,478,'10.1176/appi.ajp.2018.17111194'),(167,478,'10.3389/fpubh.2020.00146'),(168,478,'10.3389/fpubh.2020.00146'),(169,478,'10.1016/j.jpsychores.2020.110122'),(170,479,'10.21865/ridep54.1.14'),(171,479,'10.1590/1413-82712019240102'),(172,479,'10.1080/03004430.2019.1673384'),(173,479,'10.21865/ridep54.1.14'),(174,479,'10.1590/1413-82712019240102'),(175,479,'10.1080/03004430.2019.1673384'),(176,479,'10.21865/ridep54.1.14'),(177,479,'10.1590/1413-82712019240102'),(178,479,'10.1080/03004430.2019.1673384'),(179,479,'10.21865/ridep54.1.14'),(180,479,'10.1590/1413-82712019240102'),(181,479,'10.1080/03004430.2019.1673384'),(182,479,'10.21865/ridep54.1.14'),(183,479,'10.1590/1413-82712019240102'),(184,479,'10.1080/03004430.2019.1673384'),(185,479,'10.21865/ridep54.1.14'),(186,479,'10.1590/1413-82712019240102'),(187,479,'10.1080/03004430.2019.1673384'),(188,479,'10.21865/ridep54.1.14'),(189,479,'10.1590/1413-82712019240102'),(190,479,'10.1080/03004430.2019.1673384'),(191,479,'10.21865/ridep54.1.14'),(192,479,'10.1590/1413-82712019240102'),(193,479,'10.1080/03004430.2019.1673384'),(194,479,'10.21865/ridep54.1.14'),(195,479,'10.1590/1413-82712019240102'),(196,479,'10.1080/03004430.2019.1673384'),(197,479,'10.21865/ridep54.1.14'),(198,479,'10.1590/1413-82712019240102'),(199,479,'10.1080/03004430.2019.1673384'),(200,479,'10.21865/ridep54.1.14'),(201,479,'10.1590/1413-82712019240102'),(202,479,'10.1080/03004430.2019.1673384'),(203,479,'10.21865/ridep54.1.14'),(204,479,'10.1590/1413-82712019240102'),(205,479,'10.1080/03004430.2019.1673384'),(206,479,'10.21865/ridep54.1.14'),(207,479,'10.1590/1413-82712019240102'),(208,479,'10.1080/03004430.2019.1673384'),(209,479,'10.21865/ridep54.1.14'),(210,479,'10.1590/1413-82712019240102'),(211,479,'10.1080/03004430.2019.1673384'),(212,479,'10.21865/ridep54.1.14'),(213,479,'10.1590/1413-82712019240102'),(214,479,'10.1080/03004430.2019.1673384'),(215,479,'10.21865/ridep54.1.14'),(216,479,'10.1590/1413-82712019240102'),(217,479,'10.1080/03004430.2019.1673384'),(218,479,'10.21865/ridep54.1.14'),(219,479,'10.1590/1413-82712019240102'),(220,479,'10.1080/03004430.2019.1673384'),(221,479,'10.21865/ridep54.1.14'),(222,479,'10.1590/1413-82712019240102'),(223,479,'10.1080/03004430.2019.1673384'),(224,479,'10.21865/ridep54.1.14'),(225,479,'10.1590/1413-82712019240102'),(226,479,'10.1080/03004430.2019.1673384'),(227,479,'10.21865/ridep54.1.14'),(228,479,'10.1590/1413-82712019240102'),(229,479,'10.1080/03004430.2019.1673384'),(230,479,'10.21865/ridep54.1.14'),(231,479,'10.1590/1413-82712019240102'),(232,479,'10.1080/03004430.2019.1673384'),(233,479,'10.21865/ridep54.1.14'),(234,479,'10.1590/1413-82712019240102'),(235,479,'10.1080/03004430.2019.1673384'),(236,479,'10.21865/ridep54.1.14'),(237,479,'10.1590/1413-82712019240102'),(238,479,'10.1080/03004430.2019.1673384'),(239,479,'10.21865/ridep54.1.14'),(240,479,'10.1590/1413-82712019240102'),(241,479,'10.1080/03004430.2019.1673384'),(242,482,'10.1186/s12888-018-2009-z'),(243,482,'10.1016/j.ctim.2020.102321'),(244,482,'10.1016/j.ctim.2020.102321'),(245,482,'10.1093/abm/kaz060'),(246,489,'10.1016/j.neuroimage.2018.04.010'),(247,489,'10.1038/s41598-018-33923-9'),(248,489,'10.1016/j.neuroimage.2019.07.012'),(249,489,'10.1016/j.neuroimage.2018.04.010'),(250,489,'10.1038/s41598-018-33923-9'),(251,489,'10.1016/j.neuroimage.2019.07.012'),(252,489,'10.1016/j.neuroimage.2018.04.010'),(253,489,'10.1038/s41598-018-33923-9'),(254,489,'10.1016/j.neuroimage.2019.07.012'),(255,489,'10.1016/j.neuroimage.2018.04.010'),(256,489,'10.1038/s41598-018-33923-9'),(257,489,'10.1016/j.neuroimage.2019.07.012'),(258,489,'10.1016/j.neuroimage.2018.04.010'),(259,489,'10.1038/s41598-018-33923-9'),(260,489,'10.1016/j.neuroimage.2019.07.012'),(261,489,'10.1016/j.neuroimage.2018.04.010'),(262,489,'10.1038/s41598-018-33923-9'),(263,489,'10.1016/j.neuroimage.2019.07.012'),(264,489,'10.1016/j.neuroimage.2018.04.010'),(265,489,'10.1038/s41598-018-33923-9'),(266,489,'10.1016/j.neuroimage.2019.07.012'),(267,489,'10.1016/j.neuroimage.2018.04.010'),(268,489,'10.1038/s41598-018-33923-9'),(269,489,'10.1016/j.neuroimage.2019.07.012'),(270,491,'10.1007/s11199-018-0999-0'),(271,491,'10.1590/1413-82712019240107'),(272,491,'10.1007/s11199-018-0999-0'),(273,491,'10.1590/1413-82712019240107'),(274,491,'10.15448/1980-8623.2019.1.28043'),(275,491,'10.1007/s11199-018-0999-0'),(276,491,'10.1590/0102.3772e3436'),(277,491,'10.15448/1980-8623.2019.1.28043'),(278,487,'https://doi.org/10.22456/2238-152X.80420'),(279,495,'10.1002/gps.4619'),(280,495,'10.1123/japa.2016-0332'),(281,495,'10.1111/psyg.12372'),(282,495,'10.1002/gps.4619'),(283,495,'10.1123/japa.2016-0332'),(284,495,'10.1111/psyg.12372'),(285,495,'10.1002/gps.4619'),(286,495,'10.1123/japa.2016-0332'),(287,495,'10.1111/psyg.12372'),(288,495,'10.1002/gps.4619'),(289,495,'10.1123/japa.2016-0332'),(290,495,'10.1111/psyg.12372'),(291,495,'10.1002/gps.4619'),(292,495,'10.1123/japa.2016-0332'),(293,495,'10.1111/psyg.12372'),(294,495,'10.1002/gps.4619'),(295,495,'10.1123/japa.2016-0332'),(296,495,'10.1111/psyg.12372'),(297,495,'10.1123/japa.2016-0332'),(298,495,'10.1111/psyg.12372'),(299,495,'10.1002/gps.4619'),(300,495,'10.1123/japa.2016-0332'),(301,495,'10.1111/psyg.12372'),(302,495,'10.1002/gps.4619'),(303,495,'10.1123/japa.2016-0332'),(304,495,'10.1111/psyg.12372'),(305,495,'10.1002/gps.4619'),(306,495,'10.1123/japa.2016-0332'),(307,495,'10.1111/psyg.12372'),(308,495,'10.1002/gps.4619'),(309,495,'10.1123/japa.2016-0332'),(310,495,'10.1111/psyg.12372'),(311,495,'10.1002/gps.4619'),(312,495,'10.1123/japa.2016-0332'),(313,495,'10.1111/psyg.12372'),(314,495,'10.1002/gps.4619'),(315,495,'10.1123/japa.2016-0332'),(316,495,'10.1111/psyg.12372'),(317,495,'10.1002/gps.4619'),(318,495,'10.1123/japa.2016-0332'),(319,495,'10.1111/psyg.12372'),(320,495,'10.1002/gps.4619'),(321,495,'10.1123/japa.2016-0332'),(322,495,'10.1111/psyg.12372'),(323,495,'10.1002/gps.4619'),(324,495,'10.1123/japa.2016-0332'),(325,495,'10.1111/psyg.12372'),(326,495,'10.1002/gps.4619'),(327,495,'10.1123/japa.2016-0332'),(328,495,'10.1111/psyg.12372'),(329,495,'10.1002/gps.4619'),(330,495,'10.1123/japa.2016-0332'),(331,495,'10.1111/psyg.12372'),(332,516,'https://doi.org/10.1590/1518-8345.2456.3115'),(333,516,'https://doi.org/10.1590/0034-7167-2017-0444'),(334,516,'https://doi.org/10.1590/1518-8345.2456.3115'),(335,516,'https://doi.org/10.1590/0034-7167-2017-0444'),(336,521,'10.21865/ridep54.1.14'),(337,521,'10.1590/1517-869220202601218097'),(338,521,'10.1590/1413-82712019240102'),(339,521,'10.21865/ridep54.1.14'),(340,521,'10.1590/1517-869220202601218097'),(341,521,'10.1590/1413-82712019240102'),(342,526,'10.1186/s12888-020-2473-0'),(343,526,'10.1016/j.archger.2020.104048'),(344,526,'10.1186/s12888-020-2473-0'),(345,526,'10.1016/j.archger.2020.104048'),(346,526,'10.1186/s12888-020-2473-0'),(347,526,'10.1016/j.archger.2020.104048'),(348,526,'10.1186/s12888-020-2473-0'),(349,526,'10.1016/j.archger.2020.104048'),(350,526,'10.1016/j.archger.2020.104048'),(351,526,'10.1186/s12888-020-2473-0'),(352,526,'10.1186/s12888-020-2473-0'),(353,526,'10.1016/j.archger.2020.104048'),(354,526,'10.1186/s12888-020-2473-0'),(355,526,'10.1016/j.archger.2020.104048'),(356,532,'http://dx.doi.org/10.4067/S0716-10182018000600669'),(357,532,'http://dx.doi.org/10.4067/S0716-10182019000100115'),(358,532,'http://dx.doi.org/10.4067/S0716-10182018000600669'),(359,532,'http://dx.doi.org/10.4067/S0716-10182019000100115'),(360,532,'http://dx.doi.org/10.17268/sci.agropecu.2019.02.00'),(361,532,'http://dx.doi.org/10.4067/S0716-10182018000600669'),(362,532,'http://dx.doi.org/10.4067/S0716-10182019000100115'),(363,532,'http://dx.doi.org/10.17268/sci.agropecu.2019.02.00'),(364,532,'http://dx.doi.org/10.4067/S0716-10182018000600669'),(365,532,'http://dx.doi.org/10.4067/S0716-10182019000100115'),(366,532,'http://dx.doi.org/10.17268/sci.agropecu.2019.02.00'),(367,535,'10.1007/s00430-019-00578-w'),(368,535,'10.1093/femspd/fty051'),(369,535,'10.1007/s00430-019-00578-w'),(370,535,'10.1093/femspd/fty051'),(371,535,'10.1016/j.rpped.2015.12.002'),(372,535,'10.1007/s00430-019-00578-w'),(373,535,'10.1093/femspd/fty051'),(374,535,'10.1016/j.rpped.2015.12.002'),(375,535,'10.1007/s00430-019-00578-w'),(376,535,'10.1093/femspd/fty051'),(377,535,'10.1016/j.rpped.2015.12.002'),(378,535,'10.1007/s00430-019-00578-w'),(379,535,'10.1093/femspd/fty051'),(380,535,'10.1007/s00430-019-00578-w'),(381,535,'10.1093/femspd/fty051'),(382,535,'10.1016/j.rpped.2015.12.002'),(383,535,'10.1007/s00430-019-00578-w'),(384,535,'10.1093/femspd/fty051'),(385,535,'10.1016/j.rpped.2015.12.002'),(386,535,'10.1007/s00430-019-00578-w'),(387,535,'10.1093/femspd/fty051'),(388,535,'10.1016/j.rpped.2015.12.002'),(389,535,'10.1007/s00430-019-00578-w'),(390,535,'10.1093/femspd/fty051'),(391,535,'10.1016/j.rpped.2015.12.002'),(392,535,'10.1007/s00430-019-00578-w'),(393,535,'10.1093/femspd/fty051'),(394,535,'10.1016/j.rpped.2015.12.002'),(395,535,'10.1007/s00430-019-00578-w'),(396,535,'10.1093/femspd/fty051'),(397,535,'10.1016/j.rpped.2015.12.002'),(398,535,'10.1007/s00430-019-00578-w'),(399,535,'10.1093/femspd/fty051'),(400,535,'10.1016/j.rpped.2015.12.002'),(401,535,'10.1007/s00430-019-00578-w'),(402,535,'10.1093/femspd/fty051'),(403,535,'10.1016/j.rpped.2015.12.002'),(404,535,'10.1007/s00430-019-00578-w'),(405,535,'10.1093/femspd/fty051'),(406,535,'10.1016/j.rpped.2015.12.002'),(407,535,'10.1007/s00430-019-00578-w'),(408,535,'10.1093/femspd/fty051'),(409,535,'10.1016/j.rpped.2015.12.002'),(410,535,'10.1007/s00430-019-00578-w'),(411,535,'10.1093/femspd/fty051'),(412,535,'10.1016/j.rpped.2015.12.002'),(413,535,'10.1007/s00430-019-00578-w'),(414,535,'10.1093/femspd/fty051'),(415,535,'10.1016/j.rpped.2015.12.002'),(416,535,'10.1007/s00430-019-00578-w'),(417,535,'10.1093/femspd/fty051'),(418,535,'10.1016/j.rpped.2015.12.002'),(419,535,'10.1007/s00430-019-00578-w'),(420,535,'10.1093/femspd/fty051'),(421,535,'10.1016/j.rpped.2015.12.002'),(422,537,'10.1016/S0140-6736(19)31133-X'),(423,537,'10.1177/0022034519889050'),(424,537,'10.1186/s12889-019-7833-7'),(425,545,'10.17843/rpmesp.2018.354.3763'),(426,545,'10.17843/rpmesp.2019.363.4033'),(427,556,'10.4067/S0718-381X2019000200203'),(428,556,'https://doi.org/10.33326/26176068.2019.1.777'),(429,557,'10.1590/0104-0707201500000380015'),(430,557,'10.1590/S0034-71672007000500013'),(431,557,'10.1590/S0080-62342011000200008'),(432,558,'http://dx.doi.org/10.1371/journal.pone.0212617'),(433,558,'http://dx.doi.org/10.1002/ijgo.13044'),(434,560,'10.1016/j.ympev.2015.12.014'),(435,560,'10.1186/s12862-016-0735-8'),(436,560,'10.17843/rpmesp.2016.334.2577'),(437,562,'10.1127/arch.moll/1869-0963/141/001-020'),(438,562,'10.1186/s12862-016-0735-8'),(439,562,'10.1016/j.ympev.2015.12.014'),(440,565,'10.1016/j.ejogrb.2019.12.017'),(441,565,'10.1016/j.heliyon.2020.e03542'),(442,567,'https://doi.org/10.1016/j.jaerosci.2017.07.003'),(443,567,'https://doi.org/10.1016/j.atmosenv.2010.12.005'),(444,567,'https://doi.org/10.1007/s10453-010-9179-6'),(445,571,'10.4136/ambi-agua.2532'),(446,571,'10.4136/ambi-agua.1962'),(447,571,'10.3395/2317-269x.00446'),(448,572,'10.4136/ambi-agua.2532'),(449,572,'10.4136/ambi-agua.1962'),(450,572,'10.3395/2317-269x.00446'),(451,574,'10.1007/s12020-020-02240-5'),(452,574,'10.1590/0103-11042019s214'),(453,590,'http://dx.doi.org/10.1590/S0034-71672007000500013'),(454,590,'http://dx.doi.org/10.1590/S0034-71672008000100008'),(455,590,'https://doi.org/10.1590/S0080-62342011000200008'),(456,592,'10.1212/CPJ.0000000000000537'),(457,592,'10.1007/s12028-018-0602-0'),(458,593,'10.17268/sci.agropecu.2019.02.00'),(459,593,'10.4067/S0716-10182019000100115'),(460,604,'https://doi.org/10.1111/adj.12516'),(461,604,'https://doi.org/10.1016/j.archoralbio.2020.104765'),(462,604,'https://doi.org/10.1016/j.archoralbio.2020.104709'),(463,607,'https://doi.org/10.15446/rsap.v19n6.60382'),(464,607,'https://doi.org/10.1016/j.rgmx.2018.03.004'),(465,607,'DOI: 10.1016/j.rccan.2014.03.002'),(466,610,'10.1007/s40520-020-01522-2'),(467,610,'10.1590/1413-81232020253.17212018'),(468,623,'10.9788/TP2018.3-07Pt'),(469,623,'10.1080/23311908.2017.1308104'),(470,623,'10.1177/1948550619882038'),(471,640,'10.9771/cmbio.v18i3.34187'),(472,640,'10.1590/1982-021620157314'),(473,640,'10.1016/j.parkreldis.2007.08.003'),(474,642,'10.17268/sci.agropecu.2019.02.00'),(475,642,'10.4067/S0716-10182019000100115'),(476,643,'10.1016/j.parkreldis.2007.08.003'),(477,643,'10.9771/cmbio.v18i3.34187'),(478,643,'10.1590/1982-021620157314'),(479,646,'10.17268/sci.agropecu.2019.02.00'),(480,646,'10.4067/S0716-10182019000100115'),(481,654,'10.4067/S0716-10182019000100115'),(482,654,'10.17268/sci.agropecu.2019.02.00'),(483,656,'https://doi.org/10.20453/rnp.v81i3.3386'),(484,656,'10.15406/mojgg.2018.03.00118'),(485,657,'DOI: 10.1016/j.rccan.2014.03.002'),(486,657,'https://doi.org/10.1016/j.rgmx.2018.03.004'),(487,657,'DOI: https://doi.org/10.15446/rsap.v19n6.60382'),(488,659,'10.4067/S0716-10182019000100115'),(489,659,'10.17268/sci.agropecu.2019.02.00'),(490,672,'10.17268/sci.agropecu.2019.02.00'),(491,672,'10.4067/S0716-10182019000100115'),(492,673,'10.4067/S0716-10182019000100115'),(493,673,'10.17268/sci.agropecu.2019.02.00'),(494,674,'10.4067/S0716-10182019000100115'),(495,674,'10.17268/sci.agropecu.2019.02.00'),(496,664,'10.13102/rscdauefs.v6i1.1144'),(497,664,'10.34019/1809-8363.2017.v20.15998'),(498,684,'10.1590/s0103-4014.2019.3397.007'),(499,684,'10.1016/j.esd.2018.08.001'),(500,685,'10.5867/medwave.2019.09.7709'),(501,685,'10.1016/j.transproceed.2019.12.010'),(502,687,'10.3390/ijerph17093313'),(503,687,'10.5334/aogh.2745'),(504,687,'10.1590/1516-3180.2019.0313160919'),(505,690,'https://doi.org/10.3390/make1020038'),(506,690,'https://doi.org/10.3389/fams.2019.00043'),(507,690,'https://doi.org/10.3390/rs11040385'),(508,691,'10.1103/PhysRevE.101.022311'),(509,691,'10.1103/PhysRevResearch.1.033024'),(510,691,'10.1103/PhysRevE.100.052302'),(511,708,'https://doi.org/10.1111/gbb.12656'),(512,708,'https://doi.org/10.1038/s41380-019-0367-7'),(513,709,'10.1002/14651858.CD013585'),(514,709,'10.1590/1516-3180.2019.0113070519'),(515,710,'10.1002/jnr.24501'),(516,710,'10.1007/s11064-019-02843-z'),(517,713,'10.1590/0102-311X00123218'),(518,713,'10.1590/2317-6369000003118'),(519,718,'10.5020/18061230.2019.8714'),(520,718,'10.25248/reas.e1472.2019'),(521,733,'10.1590/S0034-71672007000500013'),(522,733,'10.1590/S0034-71672008000100008'),(523,733,'10.1590/S0080-62342011000200008'),(524,736,'10.5020/18061230.2019.8714'),(525,736,'10.25248/reas.e1472.2019'),(526,738,'https://doi.org/10.1590/1981-5271v44.1-20190281'),(527,738,'https://doi.org/10.1590/1413-81232018249.31142017'),(528,717,'http://dx.doi.org/10.17058/reci.v9i1.11605'),(529,717,'https://doi.org/10.1590/s1980-220x2018001903474'),(530,749,'10.1590/0034-7167-2017-0444'),(531,749,'10.1590/1518-8345.2456.3115'),(532,748,'10.1590/S1678-9946201860039'),(533,748,'10.1590/1678-9865201932e190033'),(534,755,'10.25118/2236-918x-7-3-3'),(535,755,'10.1590/1516-4446-2015-1726'),(536,755,'10.1016/j.drugalcdep.2015.07.957'),(537,759,'10.12688/F1000RESEARCH.17693.1'),(538,759,'10.1016/j.edumed.2017.11.009'),(539,760,'10.1016/S2215-0366(18)30347-X'),(540,760,'10.1016/S2215-0366(18)30300-6'),(541,764,'10.1063/5.0009454'),(542,764,'10.1103/PhysRevE.99.052208'),(543,764,'10.1063/1.5127925'),(544,765,'http://dx.doi.org/10.1590/1981-5271v44.1-20190281.ing'),(545,765,'https://doi.org/10.1590/1413-81232018249.31142017'),(546,747,'10.1590/s0102-69922017.3202009'),(547,747,'10.5020/2317-2150.2010.v15n1p58'),(548,747,'10.28998/2179-5428.20130207'),(549,770,'10.1590/1677-5449.200057'),(550,770,'10.1590/1677-5449.190059'),(551,772,'10.1590/2317-6431-2019-2180'),(552,772,'10.1007/s00405-019-05336-5'),(553,773,'https://doi.org/10.1590/1984-0462/2020/38/2020119'),(554,773,'DOI: 10.1590/S1519-38292015000100004'),(555,778,'10.36003/Rev.investig.cient.tecnol.V1N1(2017)5'),(556,778,'10.36003/Rev.investig.cient.tecnol.V2N2(2018)1'),(557,778,'10.36003/Rev.investig.cient.tecnol.V2N2(2018)2'),(558,779,'https://doi.org/10.1016/j.ajodo.2019.06.014'),(559,779,'https://doi.org/10.1111/cdoe.12454'),(560,781,'10.1590/1413-81232020256.18252018'),(561,781,'10.1016/j.heliyon.2020.e03969'),(562,791,'https://doi.org/10.1590/0103-6513.20190094'),(563,791,'https://doi.org/10.14488/1676-1901.v18i1.2727'),(564,791,'https://doi.org/10.14488/1676-1901.v18i3.2878'),(565,800,'10.37689/acta-ape/2020AR0103'),(566,800,'10.1590/1516-3180.2019.0275160919'),(567,801,'10.15446/revfacmed.v65n1Sup.59545'),(568,801,'10.15446/revfacmed.v65n1Sup.59542'),(569,801,'10.1016/j.rcae.2016.07.002'),(570,804,'https://doi.org/10.1159/000446984'),(571,804,'http://dx.doi.org/10.1590/S2317-64312014000300001392'),(572,804,'http://dx.doi.org/10.1590/2317-6431-2015-1659'),(573,805,'https://doi.org/10.1159/000446984'),(574,805,'http://dx.doi.org/10.1590/2317-6431-2015-1659'),(575,805,'http://dx.doi.org/10.1590/2317-1782/2014001IN'),(576,806,'10.1590/2317-1782/20192019120'),(577,806,'10.1590/2317-1782/20182018173'),(578,819,'10.1590/1807-3107bor-2020.vol34.0010'),(579,819,'10.1111/ger.12452'),(580,823,'https://doi.org/10.17843/rpmesp.2017.341.2709'),(581,823,'https://doi.org/10.17843/rpmesp.2018.352.3471'),(582,823,'https://doi.org/10.15381/rivep.v30i3.15564'),(583,825,'10.35366/91998'),(584,825,'http://dx.doi.org/10.30789/rcneumologia.v31.n1.2019.326'),(585,825,'https://doi.org/10.33881/2011-7191.mct.13204'),(586,826,'10.15446/revfacmed.v65n1Sup.59561'),(587,826,'10.15446/revfacmed.v65n1Sup.59542'),(588,826,'10.15446/revfacmed.v65n1Sup.59544'),(589,827,'10.1007/s12028-018-0602-0'),(590,827,'10.1212/WNL.0000000000006152'),(591,828,'http://dx.doi.org/10.17268/sci.agropecu.2019.02.00'),(592,828,'http://dx.doi.org/10.4067/S0716-10182019000100115'),(593,829,'10.1590/1982-0194201900083'),(594,829,'10.5205/1981-8963.2019.242035'),(595,829,'10.1155/2018/1414568'),(596,830,'10.2174/1573396314666181002170040'),(597,830,'10.1080/07315724.1998.10718745'),(598,830,'10.1093/jn/127.7.1407'),(599,832,'10.1590/0102-311x00167717'),(600,832,'10.1590/1414-462X201400010007'),(601,832,'10.1590/S1806-83242009000300003'),(602,834,'http://dx.doi.org/10.4257/oeco.2010.1403.04'),(603,834,'10.12662/2317-3076jhbs.v4i2.695.p65-74.2016'),(604,834,'10.1590/0074-02760150168'),(605,837,'10.1007/s10006-018-0726-6'),(606,837,'10.4317/medoral.23223'),(607,838,'10.1590/2177-9465-ean-2017-0275'),(608,838,'10.1590/s1980-220x2017042803349'),(609,846,'http://dx.doi.org/10.1590/0034-7329201900103'),(610,846,'http://dx.doi.org/10.1590/S0102-85292015000200014'),(611,846,'http://dx.doi.org/10.1590/S0102-85292015000100008'),(612,849,'10.26633/rpsp.2020.66'),(613,849,'10.1177/2380084418774316'),(614,848,'10.1590/0034-7167-2018-0331'),(615,848,'10.21675/2357-707X.2019.v10.n1.1512'),(616,852,'10.20396/san.v26i0.8655583'),(617,852,'10.12957/demetra.2018.34062'),(618,854,'10.3895/rts.v14n30.5535'),(619,854,'10.35564/jmbe.2018.0017'),(620,858,'10.1016/j.ijid.2020.06.002'),(621,858,'10.3390/pathogens9060450'),(622,858,'10.1371/journal.pone.0227472'),(623,861,'10.1093/jme/tjz053'),(624,861,'10.1007/s12304-019-09351-1'),(625,861,'10.1371/journal.pone.0053120'),(626,876,'10.1590/1413-81232020254.29802019'),(627,876,'10.5123/s1679-49742020000200024'),(628,881,'http://dx.doi.org/10.1590/1981-5271v44.1-20190281.ing'),(629,881,'https://doi.org/10.1590/1413-81232018249.31142017'),(630,890,'10.1002/jnr.24501'),(631,890,'10.1007/s11064-019-02843-z'),(632,892,'10.1093/jme/tjz053'),(633,892,'10.1007/s12304-019-09351-1'),(634,898,'10.1080/21642850.2020.1715222'),(635,898,'10.3389/fpsyg.2020.00957'),(636,898,'10.17081/psico.23.43.3379'),(637,905,'10.1080/10428194.2020.1762881'),(638,905,'10.1371/journal.pone.0233220'),(639,912,'http://dx.doi.org/10.18270/rsb.v8i1.2370'),(640,912,'10.4067/S0717-554X2019000100114'),(641,915,'https://doi.org/10.1590/1518-8345.2456.3115'),(642,915,'https://doi.org/10.1590/0034-7167-2017-0444'),(643,919,'10.4000/cea.2794'),(644,919,'10.4322/0104-4931.ctoARF1004'),(645,919,'cubo.com.br/10.4322/0104-4931.ctoAO1172'),(646,930,'10.4067/S0717-554X2019000100114'),(647,930,'10.4067/S0717-554X2017000300279'),(648,930,'10.14704/nq.2018.16.11.1858'),(649,931,'10.4067/S0717-554X2019000100114'),(650,931,'10.14704/nq.2018.16.11.1858'),(651,931,'10.4067/S0717-554X2017000300279'),(652,591,'10.1080/02699052.2018.1553312'),(653,591,'10.1212/CPJ.0000000000000537'),(654,936,'10.26633/RPSP.2020.66'),(655,936,'10.1177/2380084418774316'),(656,936,'10.5935/0104-7795.20140033'),(657,934,'10.1590/0034-7167-2017-0352'),(658,934,'10.1590/0034-7167-2018-0177'),(659,934,'10.1590/1980-265x-tce-2018-0424'),(660,945,'10.1186/s12888-018-2009-z'),(661,945,'10.4067/S0034-98872017000100021'),(662,945,'10.1016/S2214-109X(16)30188-7'),(663,948,'10.12662/2317-3076jhbs.v8i1.3297.p1-8.2020'),(664,948,'10.33448/rsd-v9i7.4548'),(665,955,'10.1590/1413-81232020252.09182018'),(666,955,'10.4322/2526-8910.ctoarf1870'),(667,957,'10.17843/rpmesp.2020.372.5396'),(668,957,'10.1002/jmv.26122'),(669,960,'10.1177/0163443720939454'),(670,960,'10.22409/contracampo.v0i0.1160'),(671,960,'10.19132/1807-8583201534.513-534'),(672,966,'10.24310/Claridades'),(673,966,'10.5209/INGE.62421'),(674,967,'https://doi.org/10.1016/j.landusepol.2020.104755'),(675,967,'http://dx.doi.org/10.12660/cgpc.v25n81.81403');
/*!40000 ALTER TABLE `doi_screening` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_decisions`
--

DROP TABLE IF EXISTS `edit_decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edit_decisions` (
  `edit_decision_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `review_round_id` bigint DEFAULT NULL,
  `stage_id` bigint DEFAULT NULL,
  `round` tinyint NOT NULL,
  `editor_id` bigint NOT NULL,
  `decision` tinyint NOT NULL,
  `date_decided` datetime NOT NULL,
  PRIMARY KEY (`edit_decision_id`),
  KEY `edit_decisions_submission_id` (`submission_id`),
  KEY `edit_decisions_editor_id` (`editor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_decisions`
--

LOCK TABLES `edit_decisions` WRITE;
/*!40000 ALTER TABLE `edit_decisions` DISABLE KEYS */;
INSERT INTO `edit_decisions` VALUES (1,2,0,5,0,1,9,'2020-09-17 17:58:47');
/*!40000 ALTER TABLE `edit_decisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `sender_id` bigint NOT NULL,
  `date_sent` datetime NOT NULL,
  `event_type` bigint DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `recipients` text,
  `cc_recipients` text,
  `bcc_recipients` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  PRIMARY KEY (`log_id`),
  KEY `email_log_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log_users`
--

DROP TABLE IF EXISTS `email_log_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log_users` (
  `email_log_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  UNIQUE KEY `email_log_user_id` (`email_log_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log_users`
--

LOCK TABLES `email_log_users` WRITE;
/*!40000 ALTER TABLE `email_log_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `email_id` bigint NOT NULL AUTO_INCREMENT,
  `email_key` varchar(64) NOT NULL,
  `context_id` bigint DEFAULT '0',
  `enabled` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email_templates_email_key` (`email_key`,`context_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_default`
--

DROP TABLE IF EXISTS `email_templates_default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_default` (
  `email_id` bigint NOT NULL AUTO_INCREMENT,
  `email_key` varchar(64) NOT NULL,
  `can_disable` tinyint NOT NULL DEFAULT '1',
  `can_edit` tinyint NOT NULL DEFAULT '1',
  `from_role_id` bigint DEFAULT NULL,
  `to_role_id` bigint DEFAULT NULL,
  PRIMARY KEY (`email_id`),
  KEY `email_templates_default_email_key` (`email_key`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_default`
--

LOCK TABLES `email_templates_default` WRITE;
/*!40000 ALTER TABLE `email_templates_default` DISABLE KEYS */;
INSERT INTO `email_templates_default` VALUES (1,'NOTIFICATION',0,1,NULL,NULL),(2,'NOTIFICATION_CENTER_DEFAULT',0,1,NULL,NULL),(3,'PASSWORD_RESET_CONFIRM',0,1,NULL,NULL),(4,'PASSWORD_RESET',0,1,NULL,NULL),(5,'USER_REGISTER',0,1,NULL,NULL),(6,'USER_VALIDATE',0,1,NULL,NULL),(7,'PUBLISH_NOTIFY',0,1,NULL,NULL),(8,'SUBMISSION_ACK',1,1,NULL,65536),(9,'SUBMISSION_ACK_NOT_USER',1,1,NULL,65536),(10,'EDITOR_ASSIGN',1,1,16,16),(11,'EDITOR_DECISION_ACCEPT',0,1,16,65536),(12,'EDITOR_DECISION_INITIAL_DECLINE',0,1,16,65536),(13,'STATISTICS_REPORT_NOTIFICATION',1,1,16,17),(14,'ANNOUNCEMENT',0,1,16,1048576),(15,'ORCID_COLLECT_AUTHOR_ID',0,1,NULL,NULL),(16,'ORCID_REQUEST_AUTHOR_AUTHORIZATION',0,1,NULL,NULL);
/*!40000 ALTER TABLE `email_templates_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_default_data`
--

DROP TABLE IF EXISTS `email_templates_default_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_default_data` (
  `email_key` varchar(64) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT 'en_US',
  `subject` varchar(120) NOT NULL,
  `body` text,
  `description` text,
  UNIQUE KEY `email_templates_default_data_pkey` (`email_key`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_default_data`
--

LOCK TABLES `email_templates_default_data` WRITE;
/*!40000 ALTER TABLE `email_templates_default_data` DISABLE KEYS */;
INSERT INTO `email_templates_default_data` VALUES ('ANNOUNCEMENT','en_US','{$title}','<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisit our website to read the <a href=\"{$url}\">full announcement</a>.','This email is sent when a new announcement is created.'),('EDITOR_ASSIGN','en_US','Moderator Assignment','{$editorialContactName}:<br />\n<br />\nThe submission, &quot;{$submissionTitle},&quot; to {$contextName} has been assigned to you to see through the screening process in your role as Moderator.<br />\n<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$editorUsername}<br />\n<br />\nThank you.','This email notifies a Moderator that the Manager has assigned them the task of overseeing a submission through the editing process. It provides information about the submission and how to access the server site.'),('EDITOR_DECISION_ACCEPT','en_US','Moderator Decision','{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Accept Submission','This email from the Manager or Moderator to an Author notifies them of a final \"accept submission\" decision regarding their submission.'),('EDITOR_DECISION_INITIAL_DECLINE','en_US','Moderator Decision','\n			{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Decline Submission','This email is sent to the author if the moderator declines his submission initially.'),('NOTIFICATION','en_US','New notification from {$siteTitle}','You have a new notification from {$siteTitle}:<br />\n<br />\n{$notificationContents}<br />\n<br />\nLink: {$url}<br />\n<br />\n{$principalContactSignature}','The email is sent to registered users that have selected to have this type of notification emailed to them.'),('NOTIFICATION','pt_BR','Nova notificação de {$siteTitle}','Você tem uma nova notificação de {$siteTitle}:<br />\n<br />\n{$notificationContents}<br />\n<br />\nLink: {$url}<br />\n<br />\n{$principalContactSignature}','O e-mail é enviado aos usuários registrados que selecionaram para receber este tipo de notificação por e-mail.'),('NOTIFICATION_CENTER_DEFAULT','en_US','A message regarding {$contextName}','Please enter your message.','The default (blank) message used in the Notification Center Message Listbuilder.'),('ORCID_COLLECT_AUTHOR_ID','de_DE','ORCID Zugriff erbeten','Liebe/r {$authorName},<br/>\n<br/>\nSie sind als Autor/in eines eingereichten Beitrags bei der Zeitschrift {$contextName} benannt worden.<br/>\n<br/>\nUm Ihre Autor/innenschaft zu bestätigen, geben Sie bitte Ihre ORCID iD für diese Einreichung an, indem Sie den unten angegebenen Link aufrufen.<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>ORCID iD registrieren oder ihre verbinden</a><br/>\n<br/>\n<br/>\n<a href=\"{$orcidAboutUrl}\">Mehr Informationen zu ORCID bei {$contextName}</a><br/>\n<br/>\nWenn Sie Fragen dazu haben, melden Sie sich bitte bei mir.<br/>\n<br/>\n{$principalContactSignature}<br/>\n','Diese E-Mail-Vorlage wird verwendet, um die ORCID-iDs von Co-Autor/innen einzuholen.'),('ORCID_COLLECT_AUTHOR_ID','en_US','Submission ORCID','Dear {$authorName},<br/>\n<br/>\nYou have been listed as an author on a manuscript submission to {$contextName}.<br/>\nTo confirm your authorship, please add your ORCID id to this submission by visiting the link provided below.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or connect your ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">More information about ORCID at {$contextName}</a><br/>\n<br/>\nIf you have any questions, please contact me.<br/>\n<br/>\n{$principalContactSignature}<br/>\n','This email template is used to collect the ORCID id\'s from authors.'),('ORCID_COLLECT_AUTHOR_ID','pt_BR','ORCID da submissão','Prezado(a) {$authorName},<br>\n<br>\nVocê foi listada(o) como um coautor(a) em uma submissão de manuscrito \"{$submissionTitle}\" para {$contextName}.<br/>\nPara confirmar sua autoria, por favor adicione sua id ORCID a esta submissão, visitando o link fornecido abaixo.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Registre ou conecte seu ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">Mais informações sobre o ORCID em {$contextName}</a><br/>\n<br/>\nSe você tiver quaisquer dúvidas, por favor entre em contato comigo.<br/>\n<br/>\n{$editorialContactSignature}<br/>\n','Este modelo de e-mail é utilizado para coletar os id ORCID dos coautores.'),('ORCID_REQUEST_AUTHOR_AUTHORIZATION','de_DE','ORCID Zugriff erbeten','Liebe/r {$authorName},<br>\n<br>\nSie sind als Autor/in des eingereichten Beitrags \"{$submissionTitle}\" bei der Zeitschrift {$contextName} benannt worden.<br>\n<br>\nBitte gestatten Sie uns Ihre ORCID-ID, falls vorhanden, zu diesem Beitrag hinzuzufügen, sowie ihr ORCID Profil bei Veröffentlichung des Beitrags zu aktualisieren.<br>\nDazu folgen Sie dem unten stehenden Link zur offiziellen ORCID-Seite, melden sich mit ihren Daten an und authorisieren Sie den Zugriff, indem\nSie den Anweisungen auf der Seite folgen.<br>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>ORCID iD registrieren oder ihre verbinden</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">Mehr Informationen zu ORCID bei {$contextName}</a>.\n<br>\nWenn Sie Fragen dazu haben, melden Sie sich bitte.<br>\n<br>\n{$principalContactSignature}<br>\n','Diese E-Mail-Vorlage wird verwendet, um die Authorisierung für ORCID Profil Zugriff von Autor/innen einzuholen.'),('ORCID_REQUEST_AUTHOR_AUTHORIZATION','en_US','Requesting ORCID record access','Dear {$authorName},<br>\n<br>\nYou have been listed as an author on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nPlease allow us to add your ORCID id to this submission and also to add the submission to your ORCID profile on publication.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n','This email template is used to request ORCID record access from authors.'),('ORCID_REQUEST_AUTHOR_AUTHORIZATION','pt_BR','Solicitando acesso ao registro ORCID','Prezado(a) {$authorName}, <br>\n<br>\nVocê foi listado como autor na submissão do manuscrito \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nPermita-nos adicionar seu ID do ORCID a essa submissão e também adicioná-lo ao seu perfil do ORCID na publicação. <br>\nVisite o link para o site oficial do ORCID, faça o login com seu perfil e autorize o acesso seguindo as instruções. <br>\n<a href=\"{$authorOrcidUrl}\"> <img id =\"orcid-id-logo\" src = \"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width = \'16 \' height = \'16 \' alt = \"Ícone ORCID iD\" style = \"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\" /> Registre ou conecte seu ORCID ID </a> <br/>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\"> Mais sobre o ORCID em {$contextName} </a> <br/>\n<br>\nSe você tiver alguma dúvida, entre em contato comigo. <br>\n<br>\n{$principalContactSignature} <br>\n','Este modelo de e-mail é usado para solicitar o acesso ao registro ORCID dos autores.'),('PASSWORD_RESET','en_US','Password Reset','Your password has been successfully reset for use with the {$siteTitle} web site. Please retain this username and password, as it is necessary for all work with the server.<br />\n<br />\nYour username: {$username}<br />\nPassword: {$password}<br />\n<br />\n{$principalContactSignature}','This email is sent to a registered user when they have successfully reset their password following the process described in the PASSWORD_RESET_CONFIRM email.'),('PASSWORD_RESET','pt_BR','Redefinição de Senha','Sua senha foi redefinida com sucesso para uso com o site {$siteTitle}. Por favor, guarde este nome de usuário e senha, pois será necessário para todo o trabalho com o servidor.<br />\n<br />\nSeu nome de usuário: {$username}<br />\nSenha: {$password}<br />\n<br />\n{$principalContactSignature}','Esse e-mail é enviado a um usuário registrado quando ele redefinir sua senha com êxito, seguindo o processo descrito no e-mail PASSWORD_RESET_CONFIRM .'),('PASSWORD_RESET_CONFIRM','en_US','Password Reset Confirmation','We have received a request to reset your password for the {$siteTitle} web site.<br />\n<br />\nIf you did not make this request, please ignore this email and your password will not be changed. If you wish to reset your password, click on the below URL.<br />\n<br />\nReset my password: {$url}<br />\n<br />\n{$principalContactSignature}','This email is sent to a registered user when they indicate that they have forgotten their password or are unable to login. It provides a URL they can follow to reset their password.'),('PASSWORD_RESET_CONFIRM','pt_BR','Confirmação de Redefinição de Senha','Recebemos uma solicitação para redefinir sua senha para o site {$siteTitle}.<br />\n<br />\nSe você não fez esta solicitação, ignore este e-mail e sua senha não será alterada. Se você deseja redefinir sua senha, clique na URL abaixo.<br />\n<br />\nRedefina minha senha: {$url}<br />\n<br />\n{$principalContactSignature}','Este e-mail é enviado a um usuário registrado quando ele indica que esqueceu sua senha ou não consegue fazer o login. Ele fornece uma URL que pode ser usada para redefinir sua senha.'),('PUBLISH_NOTIFY','en_US','New Preprint Published','Readers:<br />\n<br />\n{$contextName} has just published its latest preprint at {$contextUrl}.\n<br />\nThanks for the continuing interest in our work,<br />\n{$editorialContactSignature}','This email is sent to registered readers via the \"Notify Users\" link in the Moderator\'s User Home. It notifies readers of a new preprint and invites them to visit the server at a supplied URL.'),('PUBLISH_NOTIFY','pt_BR','Novo Preprint Postado','Leitores:<br />\n<br />\n{$contextName} acaba de publicar seu último preprint em {$contextUrl}.\n<br />\nObrigado pelo contínuo interesse em nosso trabalho,<br />\n{$editorialContactSignature}','Este e-mail é enviado aos leitores registrados através do link \"Notificar usuários\" na página do usuário do Editor. Ele notifica os leitores sobre um novo preprint e os convida a visitar o servidor em uma URL fornecida.'),('STATISTICS_REPORT_NOTIFICATION','en_US','Preprint Server activity for {$month}, {$year}','Preprint Server activity for {$month}, {$year}','Preprint Server activity for {$month}, {$year}'),('SUBMISSION_ACK','en_US','Submission Acknowledgement','{$authorName}:<br />\n<br />\nThank you for submitting the manuscript, &quot;{$submissionTitle}&quot; to {$contextName}. You can manage your submission by logging in to the server web site.<br />\\\n/>\n\"\n/>\n<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$authorUsername}<br />\n<br />\nIf you have any questions, please contact me. Thank you for considering this server as a venue for your work.<br />\n<br />\n{$editorialContactSignature}\"','This email, when enabled, is automatically sent to an author when he or she completes the process of submitting a manuscript to the server.'),('SUBMISSION_ACK','pt_BR','Confirmação de Submissão','{$authorName}:<br />\n<br />\nObrigado por submeter o manuscrito, &quot;{$submissionTitle}&quot; para {$contextName}. Você pode gerenciar sua submissão efetuando login no site do servidor.<br />\n','##emails.submissionAck.description##'),('SUBMISSION_ACK_NOT_USER','en_US','Submission Acknowledgement','Hello,<br />\n<br />\n{$submitterName} has submitted the manuscript, &quot;{$submissionTitle}&quot; to {$contextName}. <br />\n<br />\nIf you have any questions, please contact me. Thank you for considering this server as a venue for your work.<br />\n<br />\n{$editorialContactSignature}','This email, when enabled, is automatically sent to the other authors who are not users within OPS specified during the submission process.'),('USER_REGISTER','en_US','Server Registration','{$userFullName}<br />\n<br />\nYou have now been registered as a user with {$contextName}. We have included your username and password in this email, which are needed for all work with this server through its website. At any point, you can ask to be removed from the server\'s list of users by contacting me.<br />\n<br />\nUsername: {$username}<br />\nPassword: {$password}<br />\n<br />\nThank you,<br />\n{$principalContactSignature}','This email is sent to a newly registered user to welcome them to the system and provide them with a record of their username and password.'),('USER_REGISTER','pt_BR','Registro do servidor','{$userFullName}<br />\n<br />\nVocê já foi registrado como usuário com o nome {$contextName}. Incluímos seu nome de usuário e senha neste e-mail, necessários para todo o trabalho neste servidor por meio de seu site. A qualquer momento, você pode pedir para ser removido da lista de usuários do servidor entrando em contato comigo.<br />\n<br />\nNome de usuário: {$username}<br />\nSenha: {$password}<br />\n<br />\nObrigado,<br />\n{$principalContactSignature}','Esse e-mail é enviado a um usuário recém-registrado para recebê-lo no sistema e fornecer um registro do nome de usuário e senha.'),('USER_VALIDATE','en_US','Validate Your Account','{$userFullName}<br />\n<br />\nYou have created an account with {$contextName}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$principalContactSignature}','This email is sent to a newly registered user to validate their email account.'),('USER_VALIDATE','pt_BR','Valide Sua Conta','{$userFullName}<br />\n<br />\nVocê criou uma conta com {$contextName}, mas antes de começar a usá-lo, você precisa validar sua conta de e-mail. Para fazer isso, basta seguir o link abaixo:<br />\n<br />\n{$activateUrl}<br />\n<br />\nObrigado,<br />\n{$principalContactSignature}','Este e-mail é enviado a um usuário recém-registrado para validar sua conta de e-mail.');
/*!40000 ALTER TABLE `email_templates_default_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_settings`
--

DROP TABLE IF EXISTS `email_templates_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_settings` (
  `email_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  UNIQUE KEY `email_settings_pkey` (`email_id`,`locale`,`setting_name`),
  KEY `email_settings_email_id` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_settings`
--

LOCK TABLES `email_templates_settings` WRITE;
/*!40000 ALTER TABLE `email_templates_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log`
--

DROP TABLE IF EXISTS `event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `date_logged` datetime NOT NULL,
  `event_type` bigint DEFAULT NULL,
  `message` text,
  `is_translated` tinyint DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `event_log_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log`
--

LOCK TABLES `event_log` WRITE;
/*!40000 ALTER TABLE `event_log` DISABLE KEYS */;
INSERT INTO `event_log` VALUES (1,1048585,1,1,'2021-05-06 17:57:24',268435458,'submission.event.general.metadataUpdated',0),(2,515,1,1,'2021-05-06 17:57:47',1342177281,'submission.event.fileUploaded',0),(3,1048585,1,1,'2021-05-06 17:57:49',1342177281,'submission.event.fileUploaded',0),(4,1048585,1,1,'2021-05-06 17:58:45',268435458,'submission.event.general.metadataUpdated',0),(5,1048585,1,1,'2021-05-06 17:58:47',268435457,'submission.event.submissionSubmitted',0),(6,1048585,1,1,'2021-05-06 17:59:02',268435462,'publication.event.published',0),(7,1048585,2,1,'2021-05-06 17:59:29',268435458,'submission.event.general.metadataUpdated',0),(8,515,2,1,'2021-05-06 17:59:41',1342177281,'submission.event.fileUploaded',0),(9,1048585,2,1,'2021-05-06 17:59:43',1342177281,'submission.event.fileUploaded',0),(10,1048585,2,1,'2021-05-06 18:00:13',268435458,'submission.event.general.metadataUpdated',0),(11,1048585,2,1,'2021-05-06 18:00:15',268435457,'submission.event.submissionSubmitted',0),(12,1048585,2,1,'2021-05-06 18:00:25',805306371,'log.editor.decision',0);
/*!40000 ALTER TABLE `event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log_settings`
--

DROP TABLE IF EXISTS `event_log_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log_settings` (
  `log_id` bigint NOT NULL,
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `event_log_settings_pkey` (`log_id`,`setting_name`),
  KEY `event_log_settings_log_id` (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log_settings`
--

LOCK TABLES `event_log_settings` WRITE;
/*!40000 ALTER TABLE `event_log_settings` DISABLE KEYS */;
INSERT INTO `event_log_settings` VALUES (2,'fileId','1','int'),(2,'fileRevision','1','int'),(2,'fileStage','10','int'),(2,'originalFileName','preprint_com_problema.pdf','string'),(2,'revisedFileId',NULL,'string'),(2,'submissionId','1','int'),(2,'username','duarte','string'),(3,'fileId','1','int'),(3,'fileRevision','1','int'),(3,'fileStage','10','int'),(3,'name','duarte, preprint_com_problema.pdf','string'),(3,'originalFileName','preprint_com_problema.pdf','string'),(3,'submissionId','1','int'),(3,'username','duarte','string'),(8,'fileId','2','int'),(8,'fileRevision','1','int'),(8,'fileStage','10','int'),(8,'originalFileName','preprint_problema_abstract.pdf','string'),(8,'revisedFileId',NULL,'string'),(8,'submissionId','2','int'),(8,'username','duarte','string'),(9,'fileId','2','int'),(9,'fileRevision','1','int'),(9,'fileStage','10','int'),(9,'name','duarte, preprint_problema_abstract.pdf','string'),(9,'originalFileName','preprint_problema_abstract.pdf','string'),(9,'submissionId','2','int'),(9,'username','duarte','string'),(12,'decision','Rejeitar Submissão','string'),(12,'editorName','duarte duarte','string'),(12,'submissionId','2','int');
/*!40000 ALTER TABLE `event_log_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_groups`
--

DROP TABLE IF EXISTS `filter_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_groups` (
  `filter_group_id` bigint NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `output_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`filter_group_id`),
  UNIQUE KEY `filter_groups_symbolic` (`symbolic`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_groups`
--

LOCK TABLES `filter_groups` WRITE;
/*!40000 ALTER TABLE `filter_groups` DISABLE KEYS */;
INSERT INTO `filter_groups` VALUES (1,'article=>dc11','plugins.metadata.dc11.articleAdapter.displayName','plugins.metadata.dc11.articleAdapter.description','class::classes.submission.Submission','metadata::plugins.metadata.dc11.schema.Dc11Schema(ARTICLE)'),(2,'mods34=>mods34-xml','plugins.metadata.mods34.mods34XmlOutput.displayName','plugins.metadata.mods34.mods34XmlOutput.description','metadata::plugins.metadata.mods34.schema.Mods34Schema(*)','xml::schema(lib/pkp/plugins/metadata/mods34/filter/mods34.xsd)'),(3,'article=>mods34','plugins.metadata.mods34.articleAdapter.displayName','plugins.metadata.mods34.articleAdapter.description','class::classes.submission.Submission','metadata::plugins.metadata.mods34.schema.Mods34Schema(ARTICLE)'),(4,'mods34=>article','plugins.metadata.mods34.articleAdapter.displayName','plugins.metadata.mods34.articleAdapter.description','metadata::plugins.metadata.mods34.schema.Mods34Schema(ARTICLE)','class::classes.submission.Submission'),(5,'preprint=>crossref-xml','plugins.importexport.crossref.displayName','plugins.importexport.crossref.description','class::classes.submission.Submission[]','xml::schema(https://www.crossref.org/schemas/crossref4.4.0.xsd)');
/*!40000 ALTER TABLE `filter_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_settings`
--

DROP TABLE IF EXISTS `filter_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_settings` (
  `filter_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `filter_settings_pkey` (`filter_id`,`locale`,`setting_name`),
  KEY `filter_settings_id` (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_settings`
--

LOCK TABLES `filter_settings` WRITE;
/*!40000 ALTER TABLE `filter_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filters` (
  `filter_id` bigint NOT NULL AUTO_INCREMENT,
  `filter_group_id` bigint NOT NULL DEFAULT '0',
  `context_id` bigint NOT NULL DEFAULT '0',
  `display_name` varchar(255) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `is_template` tinyint NOT NULL DEFAULT '0',
  `parent_filter_id` bigint NOT NULL DEFAULT '0',
  `seq` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` VALUES (1,1,0,'Extract metadata from a(n) Submission','plugins.metadata.dc11.filter.Dc11SchemaArticleAdapter',0,0,0),(2,2,0,'MODS 3.4','lib.pkp.plugins.metadata.mods34.filter.Mods34DescriptionXmlFilter',0,0,0),(3,3,0,'Extract metadata from a(n) Submission','plugins.metadata.mods34.filter.Mods34SchemaArticleAdapter',0,0,0),(4,4,0,'Inject metadata into a(n) Submission','plugins.metadata.mods34.filter.Mods34SchemaArticleAdapter',0,0,0),(5,5,0,'Crossref XML preprint export','plugins.importexport.crossref.filter.PreprintCrossrefXmlFilter',0,0,0);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genre_settings`
--

DROP TABLE IF EXISTS `genre_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre_settings` (
  `genre_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `genre_settings_pkey` (`genre_id`,`locale`,`setting_name`),
  KEY `genre_settings_genre_id` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre_settings`
--

LOCK TABLES `genre_settings` WRITE;
/*!40000 ALTER TABLE `genre_settings` DISABLE KEYS */;
INSERT INTO `genre_settings` VALUES (1,'de_DE','name','##default.genres.article##','string'),(1,'en_US','name','Preprint Text','string'),(1,'pt_BR','name','Texto de preprint','string'),(2,'de_DE','name','##default.genres.researchInstrument##','string'),(2,'en_US','name','Research Instrument','string'),(2,'pt_BR','name','Instrumento de Pesquisa','string'),(3,'de_DE','name','##default.genres.researchMaterials##','string'),(3,'en_US','name','Research Materials','string'),(3,'pt_BR','name','Material de Pesquisa','string'),(4,'de_DE','name','##default.genres.researchResults##','string'),(4,'en_US','name','Research Results','string'),(4,'pt_BR','name','Resultado de pesquisa','string'),(5,'de_DE','name','##default.genres.transcripts##','string'),(5,'en_US','name','Transcripts','string'),(5,'pt_BR','name','Transcrições','string'),(6,'de_DE','name','##default.genres.dataAnalysis##','string'),(6,'en_US','name','Data Analysis','string'),(6,'pt_BR','name','Análise de dados','string'),(7,'de_DE','name','##default.genres.dataSet##','string'),(7,'en_US','name','Data Set','string'),(7,'pt_BR','name','Conjunto de dados','string'),(8,'de_DE','name','##default.genres.sourceTexts##','string'),(8,'en_US','name','Source Texts','string'),(8,'pt_BR','name','Textos fonte','string'),(9,'de_DE','name','Multimedia','string'),(9,'en_US','name','Multimedia','string'),(9,'pt_BR','name','Multimedia','string'),(10,'de_DE','name','Bild','string'),(10,'en_US','name','Image','string'),(10,'pt_BR','name','Imagem','string'),(11,'de_DE','name','HTML-Stylesheet','string'),(11,'en_US','name','HTML Stylesheet','string'),(11,'pt_BR','name','Folha de Estilos','string'),(12,'de_DE','name','Andere/s','string'),(12,'en_US','name','Other','string'),(12,'pt_BR','name','Outros','string');
/*!40000 ALTER TABLE `genre_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genres` (
  `genre_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `seq` bigint DEFAULT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `category` bigint NOT NULL DEFAULT '1',
  `dependent` tinyint NOT NULL DEFAULT '0',
  `supplementary` tinyint DEFAULT '0',
  `entry_key` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`genre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES (1,1,0,1,1,0,0,'SUBMISSION'),(2,1,1,1,3,0,1,'RESEARCHINSTRUMENT'),(3,1,2,1,3,0,1,'RESEARCHMATERIALS'),(4,1,3,1,3,0,1,'RESEARCHRESULTS'),(5,1,4,1,3,0,1,'TRANSCRIPTS'),(6,1,5,1,3,0,1,'DATAANALYSIS'),(7,1,6,1,3,0,1,'DATASET'),(8,1,7,1,3,0,1,'SOURCETEXTS'),(9,1,8,1,1,1,1,'MULTIMEDIA'),(10,1,9,1,2,1,0,'IMAGE'),(11,1,10,1,1,1,0,'STYLE'),(12,1,11,1,3,0,1,'OTHER');
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_views`
--

DROP TABLE IF EXISTS `item_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_views` (
  `assoc_type` bigint NOT NULL,
  `assoc_id` varchar(32) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `date_last_viewed` datetime DEFAULT NULL,
  UNIQUE KEY `item_views_pkey` (`assoc_type`,`assoc_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_views`
--

LOCK TABLES `item_views` WRITE;
/*!40000 ALTER TABLE `item_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_settings`
--

DROP TABLE IF EXISTS `journal_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_settings` (
  `journal_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) DEFAULT NULL,
  UNIQUE KEY `journal_settings_pkey` (`journal_id`,`locale`,`setting_name`),
  KEY `journal_settings_journal_id` (`journal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_settings`
--

LOCK TABLES `journal_settings` WRITE;
/*!40000 ALTER TABLE `journal_settings` DISABLE KEYS */;
INSERT INTO `journal_settings` VALUES (1,'','defaultReviewMode','2',NULL),(1,'','emailSignature','<br/>________________________________________________________________________<br/><a href=\"http://localhost:8080/index.php/r\">\nRelatorio</a>',NULL),(1,'','enableAuthorScreening','0',NULL),(1,'','enableOai','1',NULL),(1,'','itemsPerPage','25',NULL),(1,'','keywords','request',NULL),(1,'','numPageLinks','10',NULL),(1,'','numWeeksPerResponse','4',NULL),(1,'','numWeeksPerReview','4',NULL),(1,'','supportedFormLocales','a:2:{i:0;s:5:\"pt_BR\";i:1;s:5:\"en_US\";}',NULL),(1,'','supportedLocales','a:3:{i:0;s:5:\"en_US\";i:1;s:5:\"de_DE\";i:2;s:5:\"pt_BR\";}',NULL),(1,'','supportedSubmissionLocales','a:2:{i:0;s:5:\"pt_BR\";i:1;s:5:\"en_US\";}',NULL),(1,'','themePluginPath','default',NULL),(1,'de_DE','acronym',NULL,NULL),(1,'de_DE','authorInformation','##default.contextSettings.forAuthors##',NULL),(1,'de_DE','librarianInformation','##default.contextSettings.forLibrarians##',NULL),(1,'de_DE','name',NULL,NULL),(1,'de_DE','openAccessPolicy','##default.contextSettings.openAccessPolicy##',NULL),(1,'de_DE','privacyStatement','##default.contextSettings.privacyStatement##',NULL),(1,'de_DE','readerInformation','##default.contextSettings.forReaders##',NULL),(1,'de_DE','submissionChecklist','a:5:{i:0;a:2:{s:5:\"order\";i:1;s:7:\"content\";s:60:\"##default.contextSettings.checklist.notPreviouslyPublished##\";}i:1;a:2:{s:5:\"order\";i:2;s:7:\"content\";s:48:\"##default.contextSettings.checklist.fileFormat##\";}i:2;a:2:{s:5:\"order\";i:3;s:7:\"content\";s:53:\"##default.contextSettings.checklist.addressesLinked##\";}i:3;a:2:{s:5:\"order\";i:4;s:7:\"content\";s:58:\"##default.contextSettings.checklist.submissionAppearance##\";}i:4;a:2:{s:5:\"order\";i:5;s:7:\"content\";s:63:\"##default.contextSettings.checklist.bibliographicRequirements##\";}}',NULL),(1,'en_US','acronym',NULL,NULL),(1,'en_US','authorInformation','Interested in submitting to this server? We recommend that you review the <a href=\"http://localhost:8080/index.phpr/about\">About</a> page for the policies, as well as the <a href=\"http://localhost:8080/index.phpr/about/submissions#authorGuidelines\">Author Guidelines</a>. Authors need to <a href=\"http://localhost:8080/index.phpr/user/register\">register</a> prior to submitting or, if already registered, can simply <a href=\"http://localhost:8080/index.php/index/login\">log in</a> and begin the process.',NULL),(1,'en_US','librarianInformation','We encourage research librarians to list this server among their library\'s holdings. As well, it may be worth noting that this server\'s open source publishing system is suitable for libraries to host for their faculty members to use (see <a href=\"http://pkp.sfu.ca\">Public Knowledge Project</a>).',NULL),(1,'en_US','name',NULL,NULL),(1,'en_US','openAccessPolicy','This server provides immediate open access to its content on the principle that making research freely available to the public supports a greater global exchange of knowledge.',NULL),(1,'en_US','privacyStatement','<p>The names and email addresses entered in this server site will be used exclusively for the stated purposes of this server and will not be made available for any other purpose or to any other party.</p>',NULL),(1,'en_US','readerInformation','We encourage readers to sign up for the publishing notification service for this server. Use the <a href=\"http://localhost:8080/index.phpr/user/register\">Register</a> link at the top of the home page. This list also allows the server to claim a certain level of support or readership. See the <a href=\"http://localhost:8080/index.phpr/about/submissions#privacyStatement\">Privacy Statement</a>, which assures readers that their name and email address will not be used for other purposes.',NULL),(1,'en_US','submissionChecklist','a:5:{i:0;a:2:{s:5:\"order\";i:1;s:7:\"content\";s:167:\"The submission has not been previously published, nor is it before another server for consideration (or an explanation has been provided in Comments to the Moderator).\";}i:1;a:2:{s:5:\"order\";i:2;s:7:\"content\";s:82:\"The submission file is in OpenOffice, Microsoft Word, or RTF document file format.\";}i:2;a:2:{s:5:\"order\";i:3;s:7:\"content\";s:60:\"Where available, URLs for the references have been provided.\";}i:3;a:2:{s:5:\"order\";i:4;s:7:\"content\";s:239:\"The text is single-spaced; uses a 12-point font; employs italics, rather than underlining (except with URL addresses); and all illustrations, figures, and tables are placed within the text at the appropriate points, rather than at the end.\";}i:4;a:2:{s:5:\"order\";i:5;s:7:\"content\";s:99:\"The text adheres to the stylistic and bibliographic requirements outlined in the Author Guidelines.\";}}',NULL),(1,'pt_BR','acronym','r',NULL),(1,'pt_BR','authorInformation','Interessado em submeter a este servidor? Recomendamos que revise a página <a href=\"http://localhost:8080/index.phpr/about\">Sobre</a> para conhecer as políticas, assim como as <a href=\"http://localhost:8080/index.phpr/about/submissions#authorGuidelines\">Diretrizes do Autor</a>. Os autores devem <a href=\"http://localhost:8080/index.phpr/user/register\"> se registrar</a> antes de submeter ou, se já estão registrados, podem simplesmente <a href=\"http://localhost:8080/index.php/index/log in\"> logar </a> e começar o processo.',NULL),(1,'pt_BR','librarianInformation','Encorajamos aos bibliotecários de pesquisa a incluir este servidor entre aqueles existentes em suas biblioteca. Além disso, vale a pena assinalar que o sistema de publicação de código aberto deste servidor é adequado para que as bibliotecas hospedem os membros de sua faculdade (ver <a href=\"http://pkp.sfu.ca\">Public Knowledge Project</a>).',NULL),(1,'pt_BR','name','Relatorio',NULL),(1,'pt_BR','openAccessPolicy','Este servidor fornece acesso aberto imediato ao seu conteúdo, sob o princípio de que a disponibilização aberta e gratuita da pesquisa ao público apóia um maior intercâmbio global de conhecimento.',NULL),(1,'pt_BR','privacyStatement','<p>Os nomes e e-mails inseridos no site deste servidor serão utilizados exclusivamente para  as finalidades estabelecidas por este servidor e não estarão disponíveis para nenhum outro propósito nem para nenhuma outra parte.</p>',NULL),(1,'pt_BR','readerInformation','Encorajamos os leitores a se registrar no serviço de notificação de publicação deste servidor. Utilize o link <a href=\"http://localhost:8080/index.phpr/user/register\"> Registre-se </a> no link na parte superior da página de inicio. Esta lista também permite ao servidor reclamar um certo nível de suporte ou leitores. Consulte a <a href=\"http://localhost:8080/index.phpr/about/submissions#privacyStatement\"> Declaração de privacidade </a>, que garante aos leitores que seu nome e e-mail não serão utilizados para outras finalidades.',NULL),(1,'pt_BR','submissionChecklist','a:5:{i:0;a:2:{s:5:\"order\";i:1;s:7:\"content\";s:158:\"A submissão não foi publicada anteriormente, nem está em sendo considerada em outro servidor (ou uma explicação foi fornecida em Comentários ao Editor).\";}i:1;a:2:{s:5:\"order\";i:2;s:7:\"content\";s:99:\"O arquivo da submissão está em formato de arquivo de documento OpenOffice, Microsoft Word ou RTF.\";}i:2;a:2:{s:5:\"order\";i:3;s:7:\"content\";s:61:\"Onde disponíveis, as URLs das referências foram fornecidas.\";}i:3;a:2:{s:5:\"order\";i:4;s:7:\"content\";s:227:\"O texto está em espaço simples; use uma fonte 12 pontos; use itálico, em vez de sublinhado (exceto com URLs); e todas as ilustrações, figuras e tabelas são colocadas no texto nos pontos apropriados, ao invés de no final.\";}i:4;a:2:{s:5:\"order\";i:5;s:7:\"content\";s:94:\"O texto segue os requisitos estilísticos e bibliográficos descritos nas Diretrizes do Autor.\";}}',NULL);
/*!40000 ALTER TABLE `journal_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `journal_id` bigint NOT NULL AUTO_INCREMENT,
  `path` varchar(32) NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `primary_locale` varchar(14) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`journal_id`),
  UNIQUE KEY `journals_path` (`path`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES (1,'r',1,'pt_BR',1);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_file_settings`
--

DROP TABLE IF EXISTS `library_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_file_settings` (
  `file_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `library_file_settings_pkey` (`file_id`,`locale`,`setting_name`),
  KEY `library_file_settings_id` (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_file_settings`
--

LOCK TABLES `library_file_settings` WRITE;
/*!40000 ALTER TABLE `library_file_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_files`
--

DROP TABLE IF EXISTS `library_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint NOT NULL,
  `type` tinyint NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `submission_id` bigint NOT NULL,
  `public_access` tinyint DEFAULT '0',
  PRIMARY KEY (`file_id`),
  KEY `library_files_context_id` (`context_id`),
  KEY `library_files_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_files`
--

LOCK TABLES `library_files` WRITE;
/*!40000 ALTER TABLE `library_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_description_settings`
--

DROP TABLE IF EXISTS `metadata_description_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_description_settings` (
  `metadata_description_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `metadata_descripton_settings_pkey` (`metadata_description_id`,`locale`,`setting_name`),
  KEY `metadata_description_settings_id` (`metadata_description_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_description_settings`
--

LOCK TABLES `metadata_description_settings` WRITE;
/*!40000 ALTER TABLE `metadata_description_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `metadata_description_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_descriptions`
--

DROP TABLE IF EXISTS `metadata_descriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_descriptions` (
  `metadata_description_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL DEFAULT '0',
  `assoc_id` bigint NOT NULL DEFAULT '0',
  `schema_namespace` varchar(255) NOT NULL,
  `schema_name` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `seq` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`metadata_description_id`),
  KEY `metadata_descriptions_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_descriptions`
--

LOCK TABLES `metadata_descriptions` WRITE;
/*!40000 ALTER TABLE `metadata_descriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `metadata_descriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics`
--

DROP TABLE IF EXISTS `metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics` (
  `load_id` varchar(255) NOT NULL,
  `context_id` bigint NOT NULL,
  `pkp_section_id` bigint DEFAULT NULL,
  `assoc_object_type` bigint DEFAULT NULL,
  `assoc_object_id` bigint DEFAULT NULL,
  `submission_id` bigint DEFAULT NULL,
  `representation_id` bigint DEFAULT NULL,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `day` varchar(8) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `file_type` tinyint DEFAULT NULL,
  `country_id` varchar(2) DEFAULT NULL,
  `region` varchar(2) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `metric_type` varchar(255) NOT NULL,
  `metric` int NOT NULL,
  KEY `metrics_load_id` (`load_id`),
  KEY `metrics_metric_type_context_id` (`metric_type`,`context_id`),
  KEY `metrics_metric_type_submission_id_assoc_type` (`metric_type`,`submission_id`,`assoc_type`),
  KEY `metrics_metric_type_submission_id_assoc` (`metric_type`,`context_id`,`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics`
--

LOCK TABLES `metrics` WRITE;
/*!40000 ALTER TABLE `metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignment_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignment_settings` (
  `navigation_menu_item_assignment_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `navigation_menu_item_assignment_settings_pkey` (`navigation_menu_item_assignment_id`,`locale`,`setting_name`),
  KEY `assignment_settings_navigation_menu_item_assignment_id` (`navigation_menu_item_assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignment_settings`
--

LOCK TABLES `navigation_menu_item_assignment_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignments`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignments` (
  `navigation_menu_item_assignment_id` bigint NOT NULL AUTO_INCREMENT,
  `navigation_menu_id` bigint NOT NULL,
  `navigation_menu_item_id` bigint NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `seq` bigint DEFAULT '0',
  PRIMARY KEY (`navigation_menu_item_assignment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignments`
--

LOCK TABLES `navigation_menu_item_assignments` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignments` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_assignments` VALUES (1,1,1,0,0),(2,1,2,0,1),(3,1,3,0,2),(4,1,4,3,0),(5,1,5,3,1),(6,1,6,3,2),(7,1,7,3,3),(8,2,8,0,0),(9,2,9,0,1),(10,2,10,0,2),(11,2,11,10,0),(12,2,12,10,1),(13,2,13,10,2),(14,2,14,10,3),(15,3,15,0,0),(16,3,16,0,1),(17,3,17,0,2),(18,3,18,17,0),(19,3,19,17,1),(20,3,20,17,2),(21,3,21,17,3),(22,3,22,17,4);
/*!40000 ALTER TABLE `navigation_menu_item_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_settings` (
  `navigation_menu_item_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `navigation_menu_item_settings_pkey` (`navigation_menu_item_id`,`locale`,`setting_name`),
  KEY `navigation_menu_item_settings_navigation_menu_id` (`navigation_menu_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_settings`
--

LOCK TABLES `navigation_menu_item_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_settings` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_settings` VALUES (1,'','titleLocaleKey','navigation.register','string'),(2,'','titleLocaleKey','navigation.login','string'),(3,'','titleLocaleKey','{$loggedInUsername}','string'),(4,'','titleLocaleKey','navigation.dashboard','string'),(5,'','titleLocaleKey','common.viewProfile','string'),(6,'','titleLocaleKey','navigation.admin','string'),(7,'','titleLocaleKey','user.logOut','string'),(8,'','titleLocaleKey','navigation.register','string'),(9,'','titleLocaleKey','navigation.login','string'),(10,'','titleLocaleKey','{$loggedInUsername}','string'),(11,'','titleLocaleKey','navigation.dashboard','string'),(12,'','titleLocaleKey','common.viewProfile','string'),(13,'','titleLocaleKey','navigation.admin','string'),(14,'','titleLocaleKey','user.logOut','string'),(15,'','titleLocaleKey','manager.announcements','string'),(16,'','titleLocaleKey','navigation.archives','string'),(17,'','titleLocaleKey','navigation.about','string'),(18,'','titleLocaleKey','about.aboutContext','string'),(19,'','titleLocaleKey','about.submissions','string'),(20,'','titleLocaleKey','about.editorialTeam','string'),(21,'','titleLocaleKey','manager.setup.privacyStatement','string'),(22,'','titleLocaleKey','about.contact','string'),(23,'','titleLocaleKey','common.search','string');
/*!40000 ALTER TABLE `navigation_menu_item_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_items`
--

DROP TABLE IF EXISTS `navigation_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_items` (
  `navigation_menu_item_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `url` varchar(255) DEFAULT '',
  `path` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  PRIMARY KEY (`navigation_menu_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_items`
--

LOCK TABLES `navigation_menu_items` WRITE;
/*!40000 ALTER TABLE `navigation_menu_items` DISABLE KEYS */;
INSERT INTO `navigation_menu_items` VALUES (1,0,NULL,NULL,'NMI_TYPE_USER_REGISTER'),(2,0,NULL,NULL,'NMI_TYPE_USER_LOGIN'),(3,0,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(4,0,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(5,0,NULL,NULL,'NMI_TYPE_USER_PROFILE'),(6,0,NULL,NULL,'NMI_TYPE_ADMINISTRATION'),(7,0,NULL,NULL,'NMI_TYPE_USER_LOGOUT'),(8,1,NULL,NULL,'NMI_TYPE_USER_REGISTER'),(9,1,NULL,NULL,'NMI_TYPE_USER_LOGIN'),(10,1,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(11,1,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(12,1,NULL,NULL,'NMI_TYPE_USER_PROFILE'),(13,1,NULL,NULL,'NMI_TYPE_ADMINISTRATION'),(14,1,NULL,NULL,'NMI_TYPE_USER_LOGOUT'),(15,1,NULL,NULL,'NMI_TYPE_ANNOUNCEMENTS'),(16,1,NULL,NULL,'NMI_TYPE_ARCHIVES'),(17,1,NULL,NULL,'NMI_TYPE_ABOUT'),(18,1,NULL,NULL,'NMI_TYPE_ABOUT'),(19,1,NULL,NULL,'NMI_TYPE_SUBMISSIONS'),(20,1,NULL,NULL,'NMI_TYPE_EDITORIAL_TEAM'),(21,1,NULL,NULL,'NMI_TYPE_PRIVACY'),(22,1,NULL,NULL,'NMI_TYPE_CONTACT'),(23,1,NULL,NULL,'NMI_TYPE_SEARCH');
/*!40000 ALTER TABLE `navigation_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menus`
--

DROP TABLE IF EXISTS `navigation_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menus` (
  `navigation_menu_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `area_name` varchar(255) DEFAULT '',
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`navigation_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menus`
--

LOCK TABLES `navigation_menus` WRITE;
/*!40000 ALTER TABLE `navigation_menus` DISABLE KEYS */;
INSERT INTO `navigation_menus` VALUES (1,0,'user','User Navigation Menu'),(2,1,'user','User Navigation Menu'),(3,1,'primary','Primary Navigation Menu');
/*!40000 ALTER TABLE `navigation_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `note_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `contents` text,
  PRIMARY KEY (`note_id`),
  KEY `notes_assoc` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_mail_list`
--

DROP TABLE IF EXISTS `notification_mail_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_mail_list` (
  `notification_mail_list_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(90) NOT NULL,
  `confirmed` tinyint NOT NULL DEFAULT '0',
  `token` varchar(40) NOT NULL,
  `context` bigint NOT NULL,
  PRIMARY KEY (`notification_mail_list_id`),
  UNIQUE KEY `notification_mail_list_email_context` (`email`,`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_mail_list`
--

LOCK TABLES `notification_mail_list` WRITE;
/*!40000 ALTER TABLE `notification_mail_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_mail_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `notification_id` bigint NOT NULL,
  `locale` varchar(14) DEFAULT NULL,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `notification_settings_pkey` (`notification_id`,`locale`,`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_subscription_settings`
--

DROP TABLE IF EXISTS `notification_subscription_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_subscription_settings` (
  `setting_id` bigint NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` text,
  `user_id` bigint NOT NULL,
  `context` bigint NOT NULL,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_subscription_settings`
--

LOCK TABLES `notification_subscription_settings` WRITE;
/*!40000 ALTER TABLE `notification_subscription_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_subscription_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `level` bigint NOT NULL,
  `type` bigint NOT NULL,
  `date_created` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `notifications_context_id_user_id` (`context_id`,`user_id`,`level`),
  KEY `notifications_context_id` (`context_id`,`level`),
  KEY `notifications_assoc` (`assoc_type`,`assoc_id`),
  KEY `notifications_user_id_level` (`user_id`,`level`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (4,1,0,3,16777222,'2021-05-06 17:58:47',NULL,1048585,1),(5,1,0,3,16777223,'2021-05-06 17:58:47',NULL,1048585,1),(6,1,1,2,16777217,'2021-05-06 17:58:47',NULL,1048585,1),(8,1,0,2,16777243,'2021-05-06 17:58:47',NULL,1048585,1),(9,1,0,2,16777245,'2021-05-06 17:58:47',NULL,1048585,1),(11,1,0,3,16777222,'2021-05-06 18:00:15',NULL,1048585,2),(12,1,0,3,16777223,'2021-05-06 18:00:15',NULL,1048585,2),(13,1,1,2,16777217,'2021-05-06 18:00:15',NULL,1048585,2),(15,1,0,2,16777243,'2021-05-06 18:00:15',NULL,1048585,2),(16,1,0,2,16777245,'2021-05-06 18:00:15',NULL,1048585,2);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oai_resumption_tokens`
--

DROP TABLE IF EXISTS `oai_resumption_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oai_resumption_tokens` (
  `token` varchar(32) NOT NULL,
  `expire` bigint NOT NULL,
  `record_offset` int NOT NULL,
  `params` text,
  UNIQUE KEY `oai_resumption_tokens_pkey` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oai_resumption_tokens`
--

LOCK TABLES `oai_resumption_tokens` WRITE;
/*!40000 ALTER TABLE `oai_resumption_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oai_resumption_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_settings`
--

DROP TABLE IF EXISTS `plugin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugin_settings` (
  `plugin_name` varchar(80) NOT NULL,
  `context_id` bigint NOT NULL,
  `setting_name` varchar(80) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `plugin_settings_pkey` (`plugin_name`,`context_id`,`setting_name`),
  KEY `plugin_settings_plugin_name` (`plugin_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_settings`
--

LOCK TABLES `plugin_settings` WRITE;
/*!40000 ALTER TABLE `plugin_settings` DISABLE KEYS */;
INSERT INTO `plugin_settings` VALUES ('acronplugin',0,'crontab','a:7:{i:0;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:1;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:2;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:3;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:4;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:5;a:3:{s:9:\"className\";s:43:\"plugins.generic.usageStats.UsageStatsLoader\";s:9:\"frequency\";a:1:{s:4:\"hour\";i:24;}s:4:\"args\";a:1:{i:0;s:9:\"autoStage\";}}i:6;a:3:{s:9:\"className\";s:37:\"lib.pkp.classes.task.StatisticsReport\";s:9:\"frequency\";a:1:{s:3:\"day\";s:1:\"1\";}s:4:\"args\";a:0:{}}}','object'),('acronplugin',0,'enabled','1','bool'),('defaultthemeplugin',0,'enabled','1','bool'),('defaultthemeplugin',1,'enabled','1','bool'),('developedbyblockplugin',0,'enabled','0','bool'),('developedbyblockplugin',0,'seq','0','int'),('developedbyblockplugin',1,'enabled','0','bool'),('developedbyblockplugin',1,'seq','0','int'),('googlescholarplugin',1,'enabled','1','bool'),('languagetoggleblockplugin',0,'enabled','1','bool'),('languagetoggleblockplugin',0,'seq','4','int'),('languagetoggleblockplugin',1,'enabled','1','bool'),('languagetoggleblockplugin',1,'seq','4','int'),('pdfjsviewerplugin',1,'enabled','1','bool'),('tinymceplugin',0,'enabled','1','bool'),('tinymceplugin',1,'enabled','1','bool'),('usageeventplugin',0,'enabled','1','bool'),('usageeventplugin',0,'uniqueSiteId','60942c6dc78d7','string'),('usagestatsplugin',0,'accessLogFileParseRegex','/^(?P<ip>\\S+) \\S+ \\S+ \\[(?P<date>.*?)\\] \"\\S+ (?P<url>\\S+).*?\" (?P<returnCode>\\S+) \\S+ \".*?\" \"(?P<userAgent>.*?)\"/','string'),('usagestatsplugin',0,'chartType','bar','string'),('usagestatsplugin',0,'createLogFiles','1','bool'),('usagestatsplugin',0,'datasetMaxCount','4','string'),('usagestatsplugin',0,'enabled','1','bool'),('usagestatsplugin',0,'optionalColumns','a:2:{i:0;s:4:\"city\";i:1;s:6:\"region\";}','object');
/*!40000 ALTER TABLE `plugin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_categories`
--

DROP TABLE IF EXISTS `publication_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_categories` (
  `publication_id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  UNIQUE KEY `publication_categories_id` (`publication_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_categories`
--

LOCK TABLES `publication_categories` WRITE;
/*!40000 ALTER TABLE `publication_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galley_settings`
--

DROP TABLE IF EXISTS `publication_galley_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galley_settings` (
  `galley_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  UNIQUE KEY `publication_galley_settings_pkey` (`galley_id`,`locale`,`setting_name`),
  KEY `publication_galley_settings_galley_id` (`galley_id`),
  KEY `publication_galley_settings_name_value` (`setting_name`(50),`setting_value`(150))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galley_settings`
--

LOCK TABLES `publication_galley_settings` WRITE;
/*!40000 ALTER TABLE `publication_galley_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_galley_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galleys`
--

DROP TABLE IF EXISTS `publication_galleys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galleys` (
  `galley_id` bigint NOT NULL AUTO_INCREMENT,
  `locale` varchar(14) DEFAULT NULL,
  `publication_id` bigint NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `file_id` bigint DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `remote_url` varchar(2047) DEFAULT NULL,
  `is_approved` tinyint NOT NULL DEFAULT '0',
  `url_path` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`galley_id`),
  KEY `publication_galleys_publication_id` (`publication_id`),
  KEY `publication_galleys_url_path` (`url_path`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galleys`
--

LOCK TABLES `publication_galleys` WRITE;
/*!40000 ALTER TABLE `publication_galleys` DISABLE KEYS */;
INSERT INTO `publication_galleys` VALUES (1,'pt_BR',1,'PDF',1,0,'',0,''),(2,'pt_BR',2,'PDF',2,0,'',0,'');
/*!40000 ALTER TABLE `publication_galleys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_settings`
--

DROP TABLE IF EXISTS `publication_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_settings` (
  `publication_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  UNIQUE KEY `publication_settings_pkey` (`publication_id`,`locale`,`setting_name`),
  KEY `publication_settings_publication_id` (`publication_id`),
  KEY `publication_settings_name_value` (`setting_name`(50),`setting_value`(150))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_settings`
--

LOCK TABLES `publication_settings` WRITE;
/*!40000 ALTER TABLE `publication_settings` DISABLE KEYS */;
INSERT INTO `publication_settings` VALUES (1,'','categoryIds','a:0:{}'),(1,'','copyrightYear','2021'),(1,'pt_BR','abstract','<p>teste</p>'),(1,'pt_BR','copyrightHolder','Relatorio'),(1,'pt_BR','prefix',''),(1,'pt_BR','subtitle',''),(1,'pt_BR','title','Um estudo sobre a Arte da Guerra'),(2,'','categoryIds','a:0:{}'),(2,'pt_BR','abstract','<p>teste</p>'),(2,'pt_BR','prefix',''),(2,'pt_BR','subtitle',''),(2,'pt_BR','title','O caso da menina perdida em linhas de código');
/*!40000 ALTER TABLE `publication_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publications` (
  `publication_id` bigint NOT NULL AUTO_INCREMENT,
  `access_status` bigint DEFAULT '0',
  `date_published` date DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `locale` varchar(14) DEFAULT NULL,
  `primary_contact_id` bigint DEFAULT NULL,
  `section_id` bigint DEFAULT NULL,
  `submission_id` bigint NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `url_path` varchar(64) DEFAULT NULL,
  `version` bigint DEFAULT NULL,
  PRIMARY KEY (`publication_id`),
  KEY `publications_submission_id` (`submission_id`),
  KEY `publications_section_id` (`section_id`),
  KEY `publications_url_path` (`url_path`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
INSERT INTO `publications` VALUES (1,0,'2020-06-02','2021-05-06 17:59:02','pt_BR',1,2,1,3,NULL,1),(2,0,NULL,'2021-05-06 18:00:13','pt_BR',2,2,2,1,NULL,1);
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queries` (
  `query_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `stage_id` tinyint NOT NULL DEFAULT '1',
  `seq` double NOT NULL DEFAULT '0',
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `closed` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`query_id`),
  KEY `queries_assoc_id` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `query_participants`
--

DROP TABLE IF EXISTS `query_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `query_participants` (
  `query_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  UNIQUE KEY `query_participants_pkey` (`query_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `query_participants`
--

LOCK TABLES `query_participants` WRITE;
/*!40000 ALTER TABLE `query_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_assignments`
--

DROP TABLE IF EXISTS `review_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_assignments` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `reviewer_id` bigint NOT NULL,
  `competing_interests` text,
  `recommendation` tinyint DEFAULT NULL,
  `date_assigned` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `date_acknowledged` datetime DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `date_response_due` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reminder_was_automatic` tinyint NOT NULL DEFAULT '0',
  `declined` tinyint NOT NULL DEFAULT '0',
  `cancelled` tinyint NOT NULL DEFAULT '0',
  `reviewer_file_id` bigint DEFAULT NULL,
  `date_rated` datetime DEFAULT NULL,
  `date_reminded` datetime DEFAULT NULL,
  `quality` tinyint DEFAULT NULL,
  `review_round_id` bigint DEFAULT NULL,
  `stage_id` tinyint NOT NULL DEFAULT '1',
  `review_method` tinyint NOT NULL DEFAULT '1',
  `round` tinyint NOT NULL DEFAULT '1',
  `step` tinyint NOT NULL DEFAULT '1',
  `review_form_id` bigint DEFAULT NULL,
  `unconsidered` tinyint DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `review_assignments_submission_id` (`submission_id`),
  KEY `review_assignments_reviewer_id` (`reviewer_id`),
  KEY `review_assignments_form_id` (`review_form_id`),
  KEY `review_assignments_reviewer_review` (`reviewer_id`,`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_assignments`
--

LOCK TABLES `review_assignments` WRITE;
/*!40000 ALTER TABLE `review_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_files`
--

DROP TABLE IF EXISTS `review_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_files` (
  `review_id` bigint NOT NULL,
  `file_id` bigint NOT NULL,
  UNIQUE KEY `review_files_pkey` (`review_id`,`file_id`),
  KEY `review_files_review_id` (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_files`
--

LOCK TABLES `review_files` WRITE;
/*!40000 ALTER TABLE `review_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_round_files`
--

DROP TABLE IF EXISTS `review_round_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_round_files` (
  `submission_id` bigint NOT NULL,
  `review_round_id` bigint NOT NULL,
  `stage_id` tinyint NOT NULL,
  `file_id` bigint NOT NULL,
  `revision` bigint NOT NULL DEFAULT '1',
  UNIQUE KEY `review_round_files_pkey` (`submission_id`,`review_round_id`,`file_id`,`revision`),
  KEY `review_round_files_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_round_files`
--

LOCK TABLES `review_round_files` WRITE;
/*!40000 ALTER TABLE `review_round_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_round_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_rounds`
--

DROP TABLE IF EXISTS `review_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_rounds` (
  `review_round_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `stage_id` bigint DEFAULT NULL,
  `round` tinyint NOT NULL,
  `review_revision` bigint DEFAULT NULL,
  `status` bigint DEFAULT NULL,
  PRIMARY KEY (`review_round_id`),
  UNIQUE KEY `review_rounds_submission_id_stage_id_round_pkey` (`submission_id`,`stage_id`,`round`),
  KEY `review_rounds_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_rounds`
--

LOCK TABLES `review_rounds` WRITE;
/*!40000 ALTER TABLE `review_rounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_rounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_tasks`
--

DROP TABLE IF EXISTS `scheduled_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_tasks` (
  `class_name` varchar(255) NOT NULL,
  `last_run` datetime DEFAULT NULL,
  UNIQUE KEY `scheduled_tasks_pkey` (`class_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_tasks`
--

LOCK TABLES `scheduled_tasks` WRITE;
/*!40000 ALTER TABLE `scheduled_tasks` DISABLE KEYS */;
INSERT INTO `scheduled_tasks` VALUES ('lib.pkp.classes.task.StatisticsReport','2021-05-06 17:49:14'),('plugins.generic.usageStats.UsageStatsLoader','2021-05-10 18:17:06');
/*!40000 ALTER TABLE `scheduled_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_settings`
--

DROP TABLE IF EXISTS `section_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_settings` (
  `section_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `section_settings_pkey` (`section_id`,`locale`,`setting_name`),
  KEY `section_settings_section_id` (`section_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_settings`
--

LOCK TABLES `section_settings` WRITE;
/*!40000 ALTER TABLE `section_settings` DISABLE KEYS */;
INSERT INTO `section_settings` VALUES (1,'','path','preprints','string'),(1,'pt_BR','abbrev','PRE','string'),(1,'pt_BR','policy','Política padrão da seção','string'),(1,'pt_BR','title','Preprints','string'),(2,'','path','Health Sciences','string'),(2,'en_US','abbrev','HS','string'),(2,'en_US','description','','string'),(2,'en_US','identifyType','','string'),(2,'en_US','policy','','string'),(2,'en_US','title','Health Sciences','string'),(2,'pt_BR','abbrev','CS','string'),(2,'pt_BR','description','','string'),(2,'pt_BR','identifyType','','string'),(2,'pt_BR','policy','','string'),(2,'pt_BR','title','Ciência da Saúde','string');
/*!40000 ALTER TABLE `section_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `section_id` bigint NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `review_form_id` bigint DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `editor_restricted` tinyint NOT NULL DEFAULT '0',
  `meta_indexed` tinyint NOT NULL DEFAULT '0',
  `meta_reviewed` tinyint NOT NULL DEFAULT '1',
  `abstracts_not_required` tinyint NOT NULL DEFAULT '0',
  `hide_title` tinyint NOT NULL DEFAULT '0',
  `hide_author` tinyint NOT NULL DEFAULT '0',
  `abstract_word_count` bigint DEFAULT NULL,
  PRIMARY KEY (`section_id`),
  KEY `sections_journal_id` (`journal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,0,1,0,1,1,0,0,0,0),(2,1,0,2,0,1,0,0,0,0,NULL);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `ip_address` varchar(39) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created` bigint NOT NULL DEFAULT '0',
  `last_used` bigint NOT NULL DEFAULT '0',
  `remember` tinyint NOT NULL DEFAULT '0',
  `data` text,
  `domain` varchar(255) DEFAULT NULL,
  UNIQUE KEY `sessions_pkey` (`session_id`),
  KEY `sessions_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('4bqk3nl2dvqlu5sdd976blocri',1,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',1620670626,1620670694,1,'csrf|a:2:{s:9:\"timestamp\";i:1620670694;s:5:\"token\";s:32:\"454f17b99e23c3db0b46406675f22e1f\";}userId|s:1:\"1\";username|s:6:\"duarte\";','localhost'),('9cj6ojldt7budjq6ov6uffsks2',1,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36',1620325536,1620325744,0,'csrf|a:2:{s:9:\"timestamp\";i:1620325744;s:5:\"token\";s:32:\"2c1b9498b189528a2aa4f992bc2b6632\";}userId|s:1:\"1\";username|s:6:\"duarte\";','localhost'),('fcg0gnt7pboukrujccfa7aab08',1,'127.0.0.1','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',1620323346,1620324119,1,'csrf|a:2:{s:9:\"timestamp\";i:1620324115;s:5:\"token\";s:32:\"da5d07b831dbf588b6f2f90202536318\";}userId|s:1:\"1\";username|s:6:\"duarte\";currentLocale|s:5:\"en_US\";','localhost');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site` (
  `redirect` bigint NOT NULL DEFAULT '0',
  `primary_locale` varchar(14) NOT NULL,
  `min_password_length` tinyint NOT NULL DEFAULT '6',
  `installed_locales` varchar(1024) NOT NULL DEFAULT 'en_US',
  `supported_locales` varchar(1024) DEFAULT NULL,
  `original_style_file_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES (0,'pt_BR',6,'a:3:{i:0;s:5:\"en_US\";i:1;s:5:\"de_DE\";i:2;s:5:\"pt_BR\";}','a:3:{i:0;s:5:\"en_US\";i:1;s:5:\"de_DE\";i:2;s:5:\"pt_BR\";}',NULL);
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `setting_name` varchar(255) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_value` text,
  UNIQUE KEY `site_settings_pkey` (`setting_name`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES ('contactEmail','pt_BR','nao@lepidus.com.br'),('contactName','de_DE','##common.software##'),('contactName','en_US','Open Preprint Systems'),('contactName','pt_BR','Sistemas Abertos de Preprints'),('themePluginPath','','default');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_assignments`
--

DROP TABLE IF EXISTS `stage_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stage_assignments` (
  `stage_assignment_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `user_group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date_assigned` datetime NOT NULL,
  `recommend_only` tinyint NOT NULL DEFAULT '0',
  `can_change_metadata` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`stage_assignment_id`),
  UNIQUE KEY `stage_assignment` (`submission_id`,`user_group_id`,`user_id`),
  KEY `stage_assignments_submission_id` (`submission_id`),
  KEY `stage_assignments_user_group_id` (`user_group_id`),
  KEY `stage_assignments_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_assignments`
--

LOCK TABLES `stage_assignments` WRITE;
/*!40000 ALTER TABLE `stage_assignments` DISABLE KEYS */;
INSERT INTO `stage_assignments` VALUES (1,1,2,1,'2021-05-06 17:57:24',0,1),(2,2,2,1,'2021-05-06 17:59:29',0,1);
/*!40000 ALTER TABLE `stage_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subeditor_submission_group`
--

DROP TABLE IF EXISTS `subeditor_submission_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subeditor_submission_group` (
  `context_id` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `assoc_type` bigint NOT NULL,
  UNIQUE KEY `section_editors_pkey` (`context_id`,`assoc_id`,`user_id`,`assoc_type`),
  KEY `subeditor_submission_group_context_id` (`context_id`),
  KEY `subeditor_submission_group_assoc_id` (`assoc_type`,`assoc_id`),
  KEY `subeditor_submission_group_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subeditor_submission_group`
--

LOCK TABLES `subeditor_submission_group` WRITE;
/*!40000 ALTER TABLE `subeditor_submission_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `subeditor_submission_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_artwork_files`
--

DROP TABLE IF EXISTS `submission_artwork_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_artwork_files` (
  `file_id` bigint NOT NULL,
  `revision` bigint NOT NULL,
  `caption` text,
  `credit` varchar(255) DEFAULT NULL,
  `copyright_owner` varchar(255) DEFAULT NULL,
  `copyright_owner_contact` text,
  `permission_terms` text,
  `permission_file_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `contact_author` bigint DEFAULT NULL,
  PRIMARY KEY (`file_id`,`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_artwork_files`
--

LOCK TABLES `submission_artwork_files` WRITE;
/*!40000 ALTER TABLE `submission_artwork_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_artwork_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_comments`
--

DROP TABLE IF EXISTS `submission_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_comments` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `comment_type` bigint DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `author_id` bigint NOT NULL,
  `comment_title` text,
  `comments` text,
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `viewable` tinyint DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `submission_comments_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_comments`
--

LOCK TABLES `submission_comments` WRITE;
/*!40000 ALTER TABLE `submission_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_file_settings`
--

DROP TABLE IF EXISTS `submission_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_file_settings` (
  `file_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `submission_file_settings_pkey` (`file_id`,`locale`,`setting_name`),
  KEY `submission_file_settings_id` (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_file_settings`
--

LOCK TABLES `submission_file_settings` WRITE;
/*!40000 ALTER TABLE `submission_file_settings` DISABLE KEYS */;
INSERT INTO `submission_file_settings` VALUES (1,'pt_BR','name','duarte, preprint_com_problema.pdf','string'),(2,'pt_BR','name','duarte, preprint_problema_abstract.pdf','string');
/*!40000 ALTER TABLE `submission_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_files`
--

DROP TABLE IF EXISTS `submission_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `revision` bigint NOT NULL,
  `source_file_id` bigint DEFAULT NULL,
  `source_revision` bigint DEFAULT NULL,
  `submission_id` bigint NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `genre_id` bigint DEFAULT NULL,
  `file_size` bigint NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `file_stage` bigint NOT NULL,
  `direct_sales_price` varchar(255) DEFAULT NULL,
  `sales_type` varchar(255) DEFAULT NULL,
  `viewable` tinyint DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `uploader_user_id` bigint DEFAULT NULL,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`file_id`,`revision`),
  KEY `submission_files_submission_id` (`submission_id`),
  KEY `submission_files_stage_assoc` (`file_stage`,`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_files`
--

LOCK TABLES `submission_files` WRITE;
/*!40000 ALTER TABLE `submission_files` DISABLE KEYS */;
INSERT INTO `submission_files` VALUES (1,1,NULL,NULL,1,'application/pdf',1,273199,'preprint_com_problema.pdf',10,NULL,NULL,0,'2021-05-06 17:57:47','2021-05-06 17:57:47',1,521,1),(2,1,NULL,NULL,2,'application/pdf',1,283345,'preprint_problema_abstract.pdf',10,NULL,NULL,0,'2021-05-06 17:59:41','2021-05-06 17:59:41',1,521,2);
/*!40000 ALTER TABLE `submission_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_keyword_list`
--

DROP TABLE IF EXISTS `submission_search_keyword_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_keyword_list` (
  `keyword_id` bigint NOT NULL AUTO_INCREMENT,
  `keyword_text` varchar(60) NOT NULL,
  PRIMARY KEY (`keyword_id`),
  UNIQUE KEY `submission_search_keyword_text` (`keyword_text`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_keyword_list`
--

LOCK TABLES `submission_search_keyword_list` WRITE;
/*!40000 ALTER TABLE `submission_search_keyword_list` DISABLE KEYS */;
INSERT INTO `submission_search_keyword_list` VALUES (4,'arte'),(1,'duarte'),(2,'estudo'),(5,'guerra'),(3,'sobre'),(6,'teste');
/*!40000 ALTER TABLE `submission_search_keyword_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_object_keywords`
--

DROP TABLE IF EXISTS `submission_search_object_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_object_keywords` (
  `object_id` bigint NOT NULL,
  `keyword_id` bigint NOT NULL,
  `pos` int NOT NULL,
  UNIQUE KEY `submission_search_object_keywords_pkey` (`object_id`,`pos`),
  KEY `submission_search_object_keywords_keyword_id` (`keyword_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_object_keywords`
--

LOCK TABLES `submission_search_object_keywords` WRITE;
/*!40000 ALTER TABLE `submission_search_object_keywords` DISABLE KEYS */;
INSERT INTO `submission_search_object_keywords` VALUES (1,1,0),(1,1,1),(2,2,0),(2,3,1),(2,4,2),(2,5,3),(3,6,0);
/*!40000 ALTER TABLE `submission_search_object_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_objects`
--

DROP TABLE IF EXISTS `submission_search_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_objects` (
  `object_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `type` int NOT NULL,
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`object_id`),
  KEY `submission_search_object_submission` (`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_objects`
--

LOCK TABLES `submission_search_objects` WRITE;
/*!40000 ALTER TABLE `submission_search_objects` DISABLE KEYS */;
INSERT INTO `submission_search_objects` VALUES (1,1,1,0),(2,1,2,0),(3,1,4,0),(4,1,16,0),(5,1,8,0),(6,1,32,0),(7,1,64,0);
/*!40000 ALTER TABLE `submission_search_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_settings`
--

DROP TABLE IF EXISTS `submission_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_settings` (
  `submission_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  UNIQUE KEY `submission_settings_pkey` (`submission_id`,`locale`,`setting_name`),
  KEY `submission_settings_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_settings`
--

LOCK TABLES `submission_settings` WRITE;
/*!40000 ALTER TABLE `submission_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_supplementary_files`
--

DROP TABLE IF EXISTS `submission_supplementary_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_supplementary_files` (
  `file_id` bigint NOT NULL,
  `revision` bigint NOT NULL,
  PRIMARY KEY (`file_id`,`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_supplementary_files`
--

LOCK TABLES `submission_supplementary_files` WRITE;
/*!40000 ALTER TABLE `submission_supplementary_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_supplementary_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_tombstones`
--

DROP TABLE IF EXISTS `submission_tombstones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_tombstones` (
  `tombstone_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `date_deleted` datetime NOT NULL,
  `journal_id` bigint NOT NULL,
  `section_id` bigint NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`tombstone_id`),
  KEY `submission_tombstones_journal_id` (`journal_id`),
  KEY `submission_tombstones_submission_id` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_tombstones`
--

LOCK TABLES `submission_tombstones` WRITE;
/*!40000 ALTER TABLE `submission_tombstones` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_tombstones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `submission_id` bigint NOT NULL AUTO_INCREMENT,
  `locale` varchar(14) DEFAULT NULL,
  `context_id` bigint NOT NULL,
  `section_id` bigint DEFAULT NULL,
  `current_publication_id` bigint DEFAULT NULL,
  `date_last_activity` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `stage_id` bigint NOT NULL DEFAULT '1',
  `status` tinyint NOT NULL DEFAULT '1',
  `submission_progress` tinyint NOT NULL DEFAULT '1',
  `work_type` tinyint DEFAULT '0',
  PRIMARY KEY (`submission_id`),
  KEY `submissions_context_id` (`context_id`),
  KEY `submissions_publication_id` (`current_publication_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES (1,NULL,1,NULL,1,'2021-05-06 17:59:02','2020-04-29 17:58:47','2021-05-06 17:58:47',5,3,0,0),(2,NULL,1,NULL,2,'2021-05-06 18:00:25','2020-06-21 17:58:47','2021-05-06 18:00:15',5,4,0,0);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporary_files`
--

DROP TABLE IF EXISTS `temporary_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporary_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file_size` bigint NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `temporary_files_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporary_files`
--

LOCK TABLES `temporary_files` WRITE;
/*!40000 ALTER TABLE `temporary_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_temporary_records` (
  `assoc_id` bigint NOT NULL,
  `assoc_type` bigint NOT NULL,
  `day` bigint NOT NULL,
  `entry_time` bigint NOT NULL,
  `metric` bigint NOT NULL DEFAULT '1',
  `country_id` varchar(2) DEFAULT NULL,
  `region` varchar(2) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `load_id` varchar(255) NOT NULL,
  `file_type` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_temporary_records`
--

LOCK TABLES `usage_stats_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_settings`
--

DROP TABLE IF EXISTS `user_group_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_settings` (
  `user_group_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `user_group_settings_pkey` (`user_group_id`,`locale`,`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_settings`
--

LOCK TABLES `user_group_settings` WRITE;
/*!40000 ALTER TABLE `user_group_settings` DISABLE KEYS */;
INSERT INTO `user_group_settings` VALUES (1,'de_DE','name','##default.groups.name.siteAdmin##','string'),(1,'en_US','name','##default.groups.name.siteAdmin##','string'),(1,'pt_BR','name','Administrador do site','string'),(2,'','abbrevLocaleKey','default.groups.abbrev.manager','string'),(2,'','nameLocaleKey','default.groups.name.manager','string'),(2,'de_DE','abbrev','##default.groups.abbrev.manager##','string'),(2,'de_DE','name','##default.groups.name.manager##','string'),(2,'en_US','abbrev','PSM','string'),(2,'en_US','name','Preprint Server manager','string'),(2,'pt_BR','abbrev','PSM','string'),(2,'pt_BR','name','Administrador de servidores','string'),(3,'','abbrevLocaleKey','default.groups.abbrev.sectionEditor','string'),(3,'','nameLocaleKey','default.groups.name.sectionEditor','string'),(3,'de_DE','abbrev','##default.groups.abbrev.sectionEditor##','string'),(3,'de_DE','name','##default.groups.name.sectionEditor##','string'),(3,'en_US','abbrev','MOD','string'),(3,'en_US','name','Moderator','string'),(3,'pt_BR','abbrev','SecE','string'),(3,'pt_BR','name','Editor de serie','string'),(4,'','abbrevLocaleKey','default.groups.abbrev.author','string'),(4,'','nameLocaleKey','default.groups.name.author','string'),(4,'de_DE','abbrev','AU','string'),(4,'de_DE','name','Autor/in','string'),(4,'en_US','abbrev','AU','string'),(4,'en_US','name','Author','string'),(4,'pt_BR','abbrev','AU','string'),(4,'pt_BR','name','Autor','string'),(5,'','abbrevLocaleKey','default.groups.abbrev.reader','string'),(5,'','nameLocaleKey','default.groups.name.reader','string'),(5,'de_DE','abbrev','Lesen','string'),(5,'de_DE','name','Leser/in','string'),(5,'en_US','abbrev','Read','string'),(5,'en_US','name','Reader','string'),(5,'pt_BR','abbrev','LE','string'),(5,'pt_BR','name','Leitor','string');
/*!40000 ALTER TABLE `user_group_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_stage`
--

DROP TABLE IF EXISTS `user_group_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_stage` (
  `context_id` bigint NOT NULL,
  `user_group_id` bigint NOT NULL,
  `stage_id` bigint NOT NULL,
  UNIQUE KEY `user_group_stage_pkey` (`context_id`,`user_group_id`,`stage_id`),
  KEY `user_group_stage_context_id` (`context_id`),
  KEY `user_group_stage_user_group_id` (`user_group_id`),
  KEY `user_group_stage_stage_id` (`stage_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_stage`
--

LOCK TABLES `user_group_stage` WRITE;
/*!40000 ALTER TABLE `user_group_stage` DISABLE KEYS */;
INSERT INTO `user_group_stage` VALUES (1,2,1),(1,2,5),(1,3,1),(1,3,5),(1,4,1),(1,4,5);
/*!40000 ALTER TABLE `user_group_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `user_group_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `is_default` tinyint NOT NULL DEFAULT '0',
  `show_title` tinyint NOT NULL DEFAULT '1',
  `permit_self_registration` tinyint NOT NULL DEFAULT '0',
  `permit_metadata_edit` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_group_id`),
  KEY `user_groups_user_group_id` (`user_group_id`),
  KEY `user_groups_context_id` (`context_id`),
  KEY `user_groups_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (1,0,1,1,0,0,0),(2,1,16,1,0,0,1),(3,1,17,1,0,0,1),(4,1,65536,1,0,1,1),(5,1,1048576,1,0,1,0);
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_interests`
--

DROP TABLE IF EXISTS `user_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_interests` (
  `user_id` bigint NOT NULL,
  `controlled_vocab_entry_id` bigint NOT NULL,
  UNIQUE KEY `u_e_pkey` (`user_id`,`controlled_vocab_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interests`
--

LOCK TABLES `user_interests` WRITE;
/*!40000 ALTER TABLE `user_interests` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `user_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `assoc_type` bigint DEFAULT '0',
  `assoc_id` bigint DEFAULT '0',
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL,
  UNIQUE KEY `user_settings_pkey` (`user_id`,`locale`,`setting_name`,`assoc_type`,`assoc_id`),
  KEY `user_settings_user_id` (`user_id`),
  KEY `user_settings_locale_setting_name_index` (`setting_name`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
INSERT INTO `user_settings` VALUES (1,'pt_BR','givenName',0,0,'duarte','string'),(1,'pt_BR','familyName',0,0,'duarte','string'),(1,'pt_BR','biography',0,0,'','string'),(1,'pt_BR','signature',0,0,'','string'),(1,'pt_BR','affiliation',0,0,'','string'),(1,'pt_BR','preferredPublicName',0,0,'','string'),(1,'','orcid',0,0,'','string');
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_user_groups`
--

DROP TABLE IF EXISTS `user_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_user_groups` (
  `user_group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  UNIQUE KEY `user_user_groups_pkey` (`user_group_id`,`user_id`),
  KEY `user_user_groups_user_group_id` (`user_group_id`),
  KEY `user_user_groups_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_user_groups`
--

LOCK TABLES `user_user_groups` WRITE;
/*!40000 ALTER TABLE `user_user_groups` DISABLE KEYS */;
INSERT INTO `user_user_groups` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `user_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(2047) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `country` varchar(90) DEFAULT NULL,
  `locales` varchar(255) DEFAULT NULL,
  `gossip` text,
  `date_last_email` datetime DEFAULT NULL,
  `date_registered` datetime NOT NULL,
  `date_validated` datetime DEFAULT NULL,
  `date_last_login` datetime NOT NULL,
  `must_change_password` tinyint DEFAULT NULL,
  `auth_id` bigint DEFAULT NULL,
  `auth_str` varchar(255) DEFAULT NULL,
  `disabled` tinyint NOT NULL DEFAULT '0',
  `disabled_reason` text,
  `inline_help` tinyint DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_username` (`username`),
  UNIQUE KEY `users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'duarte','$2y$10$1uw6Qze5hMd4pXiXdlZao.s0MBU66Z.BUS6cG5bUioWFZdZsgSthW','nao@lepidus.com.br','','','',NULL,'','',NULL,NULL,'2021-05-06 17:49:06',NULL,'2021-05-10 18:17:14',0,NULL,NULL,0,NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `major` int NOT NULL DEFAULT '0',
  `minor` int NOT NULL DEFAULT '0',
  `revision` int NOT NULL DEFAULT '0',
  `build` int NOT NULL DEFAULT '0',
  `date_installed` datetime NOT NULL,
  `current` tinyint NOT NULL DEFAULT '0',
  `product_type` varchar(30) DEFAULT NULL,
  `product` varchar(30) DEFAULT NULL,
  `product_class_name` varchar(80) DEFAULT NULL,
  `lazy_load` tinyint NOT NULL DEFAULT '0',
  `sitewide` tinyint NOT NULL DEFAULT '0',
  UNIQUE KEY `versions_pkey` (`product_type`,`product`,`major`,`minor`,`revision`,`build`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES (1,0,0,0,'2021-05-06 17:49:06',1,'plugins.metadata','dc11','',0,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.metadata','mods34','',0,0),(1,0,1,0,'2021-05-06 17:49:06',1,'plugins.blocks','browse','BrowseBlockPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.blocks','developedBy','DevelopedByBlockPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.blocks','languageToggle','LanguageToggleBlockPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.generic','tinymce','TinyMCEPlugin',1,0),(1,2,0,0,'2021-05-06 17:49:06',1,'plugins.generic','customBlockManager','CustomBlockManagerPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.generic','usageEvent','',0,0),(1,0,1,0,'2021-05-06 17:49:06',1,'plugins.generic','pdfJsViewer','PdfJsViewerPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.generic','usageStats','UsageStatsPlugin',0,1),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.generic','crossrefDeposit','CrossrefDepositPlugin',1,0),(1,2,0,0,'2021-05-06 17:49:06',1,'plugins.generic','acron','AcronPlugin',1,1),(1,1,2,6,'2021-05-06 17:49:06',1,'plugins.generic','orcidProfile','OrcidProfilePlugin',1,0),(1,1,0,0,'2021-05-06 17:49:06',1,'plugins.generic','googleScholar','GoogleScholarPlugin',1,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.generic','googleAnalytics','GoogleAnalyticsPlugin',1,0),(2,2,0,0,'2021-05-06 17:49:06',1,'plugins.importexport','crossref','',0,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.oaiMetadataFormats','dc','',0,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.pubIds','doi','DOIPubIdPlugin',1,0),(1,1,0,0,'2021-05-06 17:49:06',1,'plugins.reports','counterReport','',0,0),(1,0,0,0,'2021-05-06 17:49:06',1,'plugins.themes','default','DefaultThemePlugin',1,0),(3,2,1,3,'2021-05-06 17:49:02',1,'core','ops','',0,1),(1,4,12,0,'2021-05-06 17:49:47',1,'plugins.reports','ScieloSubmissionsReportPlugin','',0,0);
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-10 14:18:46
